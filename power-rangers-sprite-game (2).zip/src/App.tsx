import { useCallback, useEffect, useRef, useState } from "react";
import {
  buildAnims,
  buildCivAnims,
  CharKey,
  CIV_SHEET,
  Frame,
  loadImages,
  RANGER_SHEET,
  RANGERS,
  SHEETS,
  sheetSize,
} from "./game/sprites";
import { Game, VIEW_H, VIEW_W } from "./game/engine";
import { sfx } from "./game/audio";

type Screen = "title" | "select" | "play" | "over" | "win";

/* ---------- sprite preview via CSS crop of the real sheet ---------- */
function SpriteFrame({
  sheet,
  frame,
  scale = 2,
}: {
  sheet: string;
  frame: Frame;
  scale?: number;
}) {
  const size = sheetSize(sheet);
  return (
    <div
      style={{
        width: frame.w * scale,
        height: frame.h * scale,
        backgroundImage: `url(${SHEETS[sheet]})`,
        backgroundPosition: `${-frame.x * scale}px ${-frame.y * scale}px`,
        backgroundSize: `${size.w * scale}px ${size.h * scale}px`,
        imageRendering: "pixelated",
      }}
    />
  );
}

function AnimatedRanger({
  charKey,
  form = "ranger",
  anim = "idle",
  fps = 6,
  scale = 2,
}: {
  charKey: CharKey;
  form?: "ranger" | "civ";
  anim?: "idle" | "walk" | "victory";
  fps?: number;
  scale?: number;
}) {
  const frames = (form === "civ" ? buildCivAnims(charKey) : buildAnims(charKey))[anim];
  const sheet = form === "civ" ? CIV_SHEET[charKey] : RANGER_SHEET[charKey];
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setI((v) => v + 1), 1000 / fps);
    return () => clearInterval(id);
  }, [fps]);
  const frame = frames[i % frames.length];
  return (
    <div className="flex items-end justify-center" style={{ height: 74 * scale }}>
      <SpriteFrame sheet={sheet} frame={frame} scale={scale} />
    </div>
  );
}

/* ---------- touch controls (mobile) ---------- */
const isTouchDevice = () =>
  typeof window !== "undefined" &&
  ("ontouchstart" in window || navigator.maxTouchPoints > 0);

function TouchControls({ gameRef }: { gameRef: React.MutableRefObject<Game | null> }) {
  // d-pad: tracks the active direction per pointer
  const dirRef = useRef<Map<number, string[]>>(new Map());

  const applyDpad = (e: React.PointerEvent, el: HTMLDivElement, end = false) => {
    e.preventDefault();
    const g = gameRef.current;
    if (!g) return;
    const prev = dirRef.current.get(e.pointerId) || [];
    for (const d of prev) g.release(d);
    dirRef.current.delete(e.pointerId);
    if (end) return;
    const r = el.getBoundingClientRect();
    const dx = e.clientX - (r.left + r.width / 2);
    const dy = e.clientY - (r.top + r.height / 2);
    if (Math.hypot(dx, dy) < r.width * 0.12) return;
    const dirs: string[] = [];
    const ang = Math.atan2(dy, dx);
    const oct = (a: number, b: number) => ang >= a && ang < b;
    const PI = Math.PI;
    if (oct(-PI / 8, PI / 8)) dirs.push("right");
    else if (oct(PI / 8, (3 * PI) / 8)) dirs.push("right", "down");
    else if (oct((3 * PI) / 8, (5 * PI) / 8)) dirs.push("down");
    else if (oct((5 * PI) / 8, (7 * PI) / 8)) dirs.push("left", "down");
    else if (ang >= (7 * PI) / 8 || ang < (-7 * PI) / 8) dirs.push("left");
    else if (oct((-7 * PI) / 8, (-5 * PI) / 8)) dirs.push("left", "up");
    else if (oct((-5 * PI) / 8, (-3 * PI) / 8)) dirs.push("up");
    else dirs.push("right", "up");
    for (const d of dirs) g.press(d);
    dirRef.current.set(e.pointerId, dirs);
  };

  const btn = (
    label: string,
    action: Parameters<Game["action"]>[0],
    cls: string,
    small = false
  ) => (
    <button
      onPointerDown={(e) => {
        e.preventDefault();
        gameRef.current?.action(action);
      }}
      onContextMenu={(e) => e.preventDefault()}
      className={`${small ? "h-12 w-12 text-[10px]" : "h-16 w-16 text-sm"} select-none rounded-full border-2 font-black tracking-wider active:scale-90 active:brightness-150 ${cls}`}
      style={{ touchAction: "none" }}
    >
      {label}
    </button>
  );

  return (
    <div
      className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-end justify-between px-3 pb-3 sm:px-6"
      style={{ touchAction: "none" }}
    >
      {/* d-pad */}
      <div
        className="pointer-events-auto relative h-32 w-32 rounded-full border-2 border-white/25 bg-black/35 backdrop-blur-[2px]"
        style={{ touchAction: "none" }}
        onPointerDown={(e) => applyDpad(e, e.currentTarget)}
        onPointerMove={(e) => {
          if (dirRef.current.has(e.pointerId) || e.buttons > 0)
            applyDpad(e, e.currentTarget);
        }}
        onPointerUp={(e) => applyDpad(e, e.currentTarget, true)}
        onPointerCancel={(e) => applyDpad(e, e.currentTarget, true)}
        onPointerLeave={(e) => applyDpad(e, e.currentTarget, true)}
        onContextMenu={(e) => e.preventDefault()}
      >
        <span className="absolute left-1/2 top-1 -translate-x-1/2 text-white/50">▲</span>
        <span className="absolute bottom-1 left-1/2 -translate-x-1/2 text-white/50">▼</span>
        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-white/50">◀</span>
        <span className="absolute right-2 top-1/2 -translate-y-1/2 text-white/50">▶</span>
      </div>
      {/* action buttons */}
      <div className="pointer-events-auto flex flex-col items-end gap-2">
        <div className="flex gap-2">
          {btn("MORF", "morph", "border-purple-400 bg-purple-500/30 text-purple-100", true)}
          {btn("ARMA", "special", "border-yellow-400 bg-yellow-500/30 text-yellow-100", true)}
        </div>
        <div className="flex items-end gap-2">
          {btn("PULO", "jump", "border-sky-400 bg-sky-500/30 text-sky-100", true)}
          {btn("CHUTE", "kick", "border-red-400 bg-red-500/35 text-red-100")}
          {btn("SOCO", "punch", "border-orange-400 bg-orange-500/35 text-orange-100")}
        </div>
      </div>
    </div>
  );
}

/* ---------- game canvas wrapper ---------- */
function GameView({
  charKey,
  onEnd,
}: {
  charKey: CharKey;
  onEnd: (won: boolean, score: number) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const endRef = useRef(onEnd);
  endRef.current = onEnd;
  const [touch] = useState(isTouchDevice);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const game = new Game(canvas, charKey, {
      onGameOver: (score) => endRef.current(false, score),
      onVictory: (score) => endRef.current(true, score),
    });
    gameRef.current = game;
    return () => {
      game.destroy();
      gameRef.current = null;
    };
  }, [charKey]);

  return (
    <div className="relative w-full max-w-[960px]">
      <div className="relative">
        <canvas
          ref={canvasRef}
          width={VIEW_W}
          height={VIEW_H}
          className="w-full rounded-lg border-4 border-zinc-700 shadow-[0_0_60px_rgba(60,120,255,0.25)]"
          style={{ imageRendering: "pixelated", aspectRatio: `${VIEW_W}/${VIEW_H}`, touchAction: "none" }}
        />
        {touch && <TouchControls gameRef={gameRef} />}
      </div>
      <div className="mt-3 hidden flex-wrap justify-center gap-x-6 gap-y-1 text-[11px] tracking-wider text-zinc-400 sm:flex">
        <span>← ↑ ↓ → / WASD mover</span>
        <span>ESPAÇO pular</span>
        <span>Z/J soco</span>
        <span>X/K chute (derruba)</span>
        <span className="text-purple-300">M morfar (medidor cheio)</span>
        <span>C/L arma especial (morfado)</span>
        <span className="text-zinc-500">chute no ar = voadora</span>
        <span className="text-amber-300">🔗 soco combo 1→2→3 (com knockback)</span>
      </div>
      <div className="mt-2 flex flex-wrap justify-center gap-x-5 gap-y-1 text-center text-[10px] tracking-wider text-zinc-500">
        <span>⚠ pule os <span className="text-zinc-300">espinhos</span> (ou jogue inimigos neles)</span>
        <span>📦 quebre <span className="text-zinc-300">caixotes</span> = energia</span>
        <span>🛢 chute <span className="text-zinc-300">barris</span> para atropelar vilões</span>
        <span>🟣 <span className="text-zinc-300">gosma</span> escorrega</span>
        <span>🔥 não encoste nos tonéis em chamas</span>
      </div>
    </div>
  );
}

/* ---------- screens ---------- */
const bolt = (
  <svg viewBox="0 0 24 24" className="h-10 w-10 fill-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.8)]">
    <path d="M13 2 4.5 13.5H11L9.5 22 19 10h-6.5L13 2z" />
  </svg>
);

export default function App() {
  const [screen, setScreen] = useState<Screen>("title");
  const [loaded, setLoaded] = useState(false);
  const [charKey, setCharKey] = useState<CharKey>("red");
  const [score, setScore] = useState(0);
  const [selIdx, setSelIdx] = useState(0);

  useEffect(() => {
    loadImages()
      .then(() => setLoaded(true))
      .catch((e) => console.error(e));
  }, []);

  const startGame = useCallback((k: CharKey) => {
    setCharKey(k);
    sfx.morphin();
    setScreen("play");
  }, []);

  const onEnd = useCallback((won: boolean, s: number) => {
    setScore(s);
    setScreen(won ? "win" : "over");
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a14] text-white [background-image:radial-gradient(ellipse_at_top,rgba(40,60,140,0.35),transparent_60%),radial-gradient(ellipse_at_bottom,rgba(120,20,40,0.25),transparent_60%)]">
      <div className="mx-auto flex min-h-[100dvh] max-w-6xl flex-col items-center justify-center px-2 py-4 sm:px-4 sm:py-8">
        {!loaded ? (
          <div className="animate-pulse text-xl tracking-[0.3em] text-zinc-400">
            CARREGANDO SPRITES…
          </div>
        ) : screen === "title" ? (
          <div className="flex flex-col items-center text-center">
            <div className="mb-4 flex items-center gap-3">
              {bolt}
              <span className="text-sm font-bold tracking-[0.5em] text-zinc-400">
                MIGHTY MORPHIN
              </span>
              {bolt}
            </div>
            <h1
              className="text-6xl font-black italic tracking-tight text-transparent sm:text-8xl"
              style={{
                backgroundImage: "linear-gradient(180deg,#fff 0%,#ffd94a 35%,#ff3d2e 70%,#8a1010 100%)",
                WebkitBackgroundClip: "text",
                filter: "drop-shadow(0 4px 0 #300) drop-shadow(0 0 30px rgba(255,80,40,0.5))",
              }}
            >
              POWER RANGERS
            </h1>
            <p className="mt-3 text-lg font-bold tracking-[0.35em] text-blue-300">
              BATALHA DE ANGEL GROVE
            </p>
            <div className="mt-10 flex items-end gap-4 rounded-2xl border border-zinc-700/60 bg-black/40 px-8 py-4">
              {RANGERS.map((r) => (
                <div key={r.key} className="hidden sm:block">
                  <AnimatedRanger charKey={r.key} scale={2} />
                </div>
              ))}
              <div className="sm:hidden">
                <AnimatedRanger charKey="red" scale={2} />
              </div>
            </div>
            <button
              onClick={() => {
                sfx.unlock();
                sfx.select();
                setScreen("select");
              }}
              className="mt-10 animate-pulse rounded-xl border-2 border-yellow-400 bg-yellow-400/10 px-10 py-4 text-xl font-black tracking-[0.3em] text-yellow-300 transition hover:scale-105 hover:bg-yellow-400/25"
            >
              INICIAR
            </button>
            <p className="mt-6 max-w-md text-xs leading-5 text-zinc-500">
              Ivan Ooze soltou a Patrulha Putty em Angel Grove. Você começa{" "}
              <span className="text-zinc-300">à paisana</span> — lute para encher o
              medidor de morfagem e aperte <span className="text-purple-300">M</span>{" "}
              para se transformar! Atravesse <span className="text-zinc-300">6 fases</span>{" "}
              cheias de espinhos, barris para chutar, caixotes com energia, gosma
              escorregadia, tonéis em chamas, vigas caindo e novos vilões — Skelerena e
              os Homens de Gosma. Cada Ranger tem seu próprio combo 1-2-3 e a arma
              personalizada do Mega Drive!
            </p>
            <div className="mt-4 flex max-w-xl flex-wrap justify-center gap-2 text-[10px] tracking-widest text-zinc-500">
              <span className="rounded border border-zinc-700 px-2 py-1">1 · OBRAS DA CIDADE</span>
              <span className="rounded border border-zinc-700 px-2 py-1">2 · PARQUE DE DIVERSÕES</span>
              <span className="rounded border border-zinc-700 px-2 py-1">3 · RODOVIA DA PONTE</span>
              <span className="rounded border border-amber-900 px-2 py-1 text-amber-500">4 · OBRAS AO ENTARDECER ⚠</span>
              <span className="rounded border border-blue-900 px-2 py-1 text-blue-400">5 · PARQUE À NOITE ⚡</span>
              <span className="rounded border border-red-900 px-2 py-1 text-red-400">6 · PONTE EM CHAMAS 🔥</span>
            </div>
          </div>
        ) : screen === "select" ? (
          <div className="flex w-full flex-col items-center">
            <h2 className="mb-1 text-3xl font-black italic tracking-widest text-yellow-300">
              ESCOLHA SEU RANGER
            </h2>
            <p className="mb-8 text-xs tracking-[0.3em] text-zinc-400">
              É HORA DE MORFAR!
            </p>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
              {RANGERS.map((r, i) => (
                <button
                  key={r.key}
                  onMouseEnter={() => setSelIdx(i)}
                  onClick={() => startGame(r.key)}
                  className={`group flex flex-col items-center rounded-xl border-2 bg-black/50 px-4 pb-4 pt-2 transition hover:scale-105 ${
                    selIdx === i ? "shadow-[0_0_25px_var(--glow)]" : ""
                  }`}
                  style={
                    {
                      borderColor: r.color,
                      "--glow": r.glow + "66",
                    } as React.CSSProperties
                  }
                >
                  <div className="hidden items-end gap-1 sm:flex">
                    <AnimatedRanger charKey={r.key} form="civ" anim="idle" fps={5} scale={1} />
                    <span className="pb-6 text-[10px] text-zinc-500">➜</span>
                    <AnimatedRanger
                      charKey={r.key}
                      anim={selIdx === i ? "walk" : "idle"}
                      fps={selIdx === i ? 10 : 5}
                      scale={1.5}
                    />
                  </div>
                  <div className="flex items-end justify-center sm:hidden">
                    <AnimatedRanger
                      charKey={r.key}
                      anim={selIdx === i ? "walk" : "idle"}
                      fps={selIdx === i ? 10 : 5}
                      scale={2}
                    />
                  </div>
                  <div className="mt-2 text-sm font-black tracking-wider" style={{ color: r.glow }}>
                    {r.name.replace("Ranger ", "").toUpperCase()}
                  </div>
                  <div className="text-[10px] text-zinc-400">{r.human}</div>
                  <div className="mt-1 text-[9px] tracking-wider text-zinc-500">{r.weapon}</div>
                </button>
              ))}
            </div>
            <button
              onClick={() => setScreen("title")}
              className="mt-8 text-xs tracking-[0.3em] text-zinc-500 hover:text-zinc-300"
            >
              ← VOLTAR
            </button>
          </div>
        ) : screen === "play" ? (
          <GameView charKey={charKey} onEnd={onEnd} />
        ) : (
          <div className="flex flex-col items-center text-center">
            {screen === "win" ? (
              <>
                <h2 className="text-5xl font-black italic text-green-400 drop-shadow-[0_0_25px_rgba(74,222,128,0.5)]">
                  VITÓRIA!
                </h2>
                <p className="mt-2 text-sm tracking-[0.25em] text-zinc-300">
                  ANGEL GROVE ESTÁ SALVA
                </p>
                <div className="mt-6">
                  <AnimatedRanger charKey={charKey} anim="victory" fps={3} scale={2} />
                </div>
              </>
            ) : (
              <>
                <h2 className="text-5xl font-black italic text-red-500 drop-shadow-[0_0_25px_rgba(239,68,68,0.5)]">
                  GAME OVER
                </h2>
                <p className="mt-2 text-sm tracking-[0.25em] text-zinc-400">
                  OS PUTTIES DOMINARAM ANGEL GROVE…
                </p>
              </>
            )}
            <div className="mt-6 rounded-xl border border-zinc-700 bg-black/50 px-10 py-4 text-2xl font-black tracking-widest text-yellow-300">
              {String(score).padStart(6, "0")} PTS
            </div>
            <div className="mt-8 flex gap-4">
              <button
                onClick={() => {
                  sfx.select();
                  setScreen("play");
                }}
                className="rounded-lg border-2 border-yellow-400 px-6 py-3 text-sm font-black tracking-widest text-yellow-300 hover:bg-yellow-400/15"
              >
                JOGAR DE NOVO
              </button>
              <button
                onClick={() => {
                  sfx.select();
                  setScreen("select");
                }}
                className="rounded-lg border-2 border-zinc-600 px-6 py-3 text-sm font-black tracking-widest text-zinc-300 hover:bg-zinc-700/40"
              >
                TROCAR RANGER
              </button>
            </div>
          </div>
        )}
        <div className="mt-8 text-center text-[10px] leading-4 text-zinc-600">
          Rangers morfados: “MMPR: The Movie” (Mega Drive/Genesis). Civis, Putties e
          cenários: “MMPR: The Movie” (SNES) — rips de Belial &amp; Cyrus Annihilator
          (The Spriters Resource).
        </div>
      </div>
    </div>
  );
}
