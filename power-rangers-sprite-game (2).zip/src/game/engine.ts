/* Beat 'em up engine — Power Rangers vs forças de Ivan Ooze (6 fases)
   Stage physics: solid objects, floor spikes, retractable spikes, slippery ooze,
   breakable crates (health drops), kickable rolling barrels, fire drums,
   airborne knockdowns with bounce, per-stage dynamic hazards. */
import {
  AnimSet,
  CharKey,
  EnemyKind,
  Frame,
  RANGER_SHEET,
  CIV_SHEET,
  WEAPON_SPECS,
  WeaponFx,
  buildAnims,
  buildCivAnims,
  buildEnemyAnims,
  getImage,
  getWeaponFrames,
  skelerenaIsFallback,
} from "./sprites";
import { sfx } from "./audio";

export const VIEW_W = 960;
export const VIEW_H = 448; // 224 (SNES) × 2 — pixel-perfect

const Z_MIN = 0;
const Z_MAX = 1;
// ground line is calibrated to the SNES sheets (224 tall): the scenery’s
// playable floor begins at y=176 and extends to y=216 (240×2 in our 448-tall view).
const GROUND_TOP = 352; // = 176 × 2
const GROUND_BOT = 432; // = 216 × 2
const ZPX = GROUND_BOT - GROUND_TOP; // screen px per z unit
const SCALE = 2;
const GRAV = 2600;

// morph cinematic timings (seconds)
const MORPH_DUR = 2.9;
const MORPH_ARM_UP = 0.9; // arm thrust to the sky
const MORPH_STRIKE = 1.7; // lightning strike + transformation

/* ---------------- stage / hazard definitions ---------------- */

type HazardType = "girder" | "fire" | "spark";

interface HazardDef {
  type: HazardType;
  every: [number, number];
  dmg: number;
}

type ObjKind = "spikes" | "retract" | "ooze" | "crate" | "barrel" | "firebarrel";

interface ObjDef {
  kind: ObjKind;
  x: number; // fraction of world width
  z: number; // 0..1
}

type Ambient = "dust" | "embers" | "sparkles" | "none";

export interface StageDef {
  img: string;
  imgW: number;
  name: string;
  waves: number[];
  enemies: EnemyKind[];
  hazard?: HazardDef;
  objects: ObjDef[];
  ambient: Ambient;
}

export const STAGES: StageDef[] = [
  {
    img: "stage1",
    imgW: 2048,
    name: "OBRAS DA CIDADE",
    waves: [3, 5],
    enemies: ["putty"],
    ambient: "dust",
    objects: [
      { kind: "crate", x: 0.17, z: 0.72 },
      { kind: "crate", x: 0.19, z: 0.3 },
      { kind: "barrel", x: 0.4, z: 0.5 },
      { kind: "spikes", x: 0.58, z: 0.25 },
      { kind: "crate", x: 0.76, z: 0.62 },
      { kind: "barrel", x: 0.9, z: 0.3 },
    ],
  },
  {
    img: "stage2",
    imgW: 1920,
    name: "PARQUE DE DIVERSÕES",
    waves: [4, 6],
    enemies: ["putty"],
    ambient: "none",
    objects: [
      { kind: "ooze", x: 0.22, z: 0.5 },
      { kind: "crate", x: 0.4, z: 0.28 },
      { kind: "retract", x: 0.55, z: 0.62 },
      { kind: "barrel", x: 0.7, z: 0.5 },
      { kind: "ooze", x: 0.85, z: 0.4 },
      { kind: "crate", x: 0.93, z: 0.7 },
    ],
  },
  {
    img: "stage3",
    imgW: 2048,
    name: "RODOVIA DA PONTE",
    waves: [5, 7],
    enemies: ["putty", "skelerena"],
    ambient: "none",
    objects: [
      { kind: "firebarrel", x: 0.2, z: 0.2 },
      { kind: "spikes", x: 0.38, z: 0.72 },
      { kind: "barrel", x: 0.5, z: 0.4 },
      { kind: "barrel", x: 0.53, z: 0.78 },
      { kind: "firebarrel", x: 0.7, z: 0.8 },
      { kind: "crate", x: 0.85, z: 0.5 },
    ],
  },
  {
    img: "stage4",
    imgW: 2048,
    name: "OBRAS AO ENTARDECER",
    waves: [5, 6, 7],
    enemies: ["putty", "skelerena"],
    hazard: { type: "girder", every: [4, 7], dmg: 16 },
    ambient: "dust",
    objects: [
      { kind: "spikes", x: 0.15, z: 0.5 },
      { kind: "crate", x: 0.3, z: 0.25 },
      { kind: "barrel", x: 0.45, z: 0.6 },
      { kind: "retract", x: 0.6, z: 0.35 },
      { kind: "spikes", x: 0.75, z: 0.8 },
      { kind: "crate", x: 0.88, z: 0.5 },
      { kind: "barrel", x: 0.93, z: 0.2 },
    ],
  },
  {
    img: "stage5",
    imgW: 1920,
    name: "PARQUE À NOITE",
    waves: [6, 7, 8],
    enemies: ["putty", "oozeman"],
    hazard: { type: "spark", every: [3.5, 6], dmg: 12 },
    ambient: "sparkles",
    objects: [
      { kind: "ooze", x: 0.15, z: 0.6 },
      { kind: "retract", x: 0.3, z: 0.4 },
      { kind: "crate", x: 0.42, z: 0.72 },
      { kind: "ooze", x: 0.55, z: 0.3 },
      { kind: "retract", x: 0.68, z: 0.7 },
      { kind: "barrel", x: 0.8, z: 0.5 },
      { kind: "ooze", x: 0.9, z: 0.5 },
    ],
  },
  {
    img: "stage6",
    imgW: 2048,
    name: "PONTE EM CHAMAS",
    waves: [6, 8, 9],
    enemies: ["putty", "skelerena", "oozeman"],
    hazard: { type: "fire", every: [3, 5.5], dmg: 14 },
    ambient: "embers",
    objects: [
      { kind: "firebarrel", x: 0.12, z: 0.3 },
      { kind: "spikes", x: 0.25, z: 0.62 },
      { kind: "ooze", x: 0.38, z: 0.4 },
      { kind: "barrel", x: 0.5, z: 0.5 },
      { kind: "firebarrel", x: 0.6, z: 0.76 },
      { kind: "spikes", x: 0.72, z: 0.25 },
      { kind: "ooze", x: 0.82, z: 0.6 },
      { kind: "firebarrel", x: 0.9, z: 0.4 },
      { kind: "crate", x: 0.95, z: 0.7 },
    ],
  },
];

const OBJ_SIZE: Record<ObjKind, { w: number; zr: number }> = {
  spikes: { w: 62, zr: 0.13 },
  retract: { w: 54, zr: 0.12 },
  ooze: { w: 84, zr: 0.22 },
  crate: { w: 22, zr: 0.09 },
  barrel: { w: 20, zr: 0.08 },
  firebarrel: { w: 20, zr: 0.08 },
};

/* ---------------- fighter ---------------- */

type State =
  | "idle"
  | "walk"
  | "jump"
  | "attack"
  | "special"
  | "hurt"
  | "fall"
  | "down"
  | "getup"
  | "dead"
  | "victory"
  | "morph";

interface Anim {
  frames: Frame[];
  fps: number;
  loop: boolean;
}

interface AttackSpec {
  anim: Anim;
  hitFrame: number;
  dmg: number;
  range: number;
  knockdown: boolean;
  aoe?: boolean;
  lungeSpeed?: number;
  weaponFx?: WeaponFx;
}

class Fighter {
  x = 0;
  z = 0.5;
  h = 0;
  vy = 0;
  vx = 0;
  mvx = 0; // movement velocity (momentum on ooze)
  mvz = 0;
  facing = 1;
  state: State = "idle";
  t = 0;
  hp: number;
  maxHp: number;
  anims: AnimSet;
  sheet: string;
  speed: number;
  isPlayer: boolean;
  kind: EnemyKind | "player" = "player";
  attack: AttackSpec | null = null;
  didHit = false;
  downT = 0;
  invuln = 0;
  flicker = 0;
  hitFlash = 0;
  dead = false;
  attackCd = 0;
  removeT = -1;
  blockT = 0;
  blockDir = 1;
  onOoze = false;

  constructor(sheet: string, anims: AnimSet, hp: number, speed: number, isPlayer: boolean) {
    this.sheet = sheet;
    this.anims = anims;
    this.hp = hp;
    this.maxHp = hp;
    this.speed = speed;
    this.isPlayer = isPlayer;
  }

  setState(s: State) {
    if (this.state === s) return;
    this.state = s;
    this.t = 0;
    this.didHit = false;
  }

  knocked(): boolean {
    return ["hurt", "fall", "down", "getup", "dead"].includes(this.state);
  }

  currentAnim(): Anim {
    const a = this.anims;
    switch (this.state) {
      case "walk":
        return { frames: a.walk, fps: 7, loop: true };
      case "jump":
        return { frames: this.vy < 0 ? a.jumpUp : a.jumpDown, fps: 5, loop: true };
      case "attack":
      case "special":
        return this.attack ? this.attack.anim : { frames: a.idle, fps: 5, loop: true };
      case "hurt":
        return { frames: a.hurt, fps: 6, loop: false };
      case "fall":
        return { frames: a.fall, fps: 6, loop: false };
      case "down":
      case "dead":
        return { frames: a.down, fps: 3, loop: false };
      case "getup":
        return { frames: [...a.fall].reverse(), fps: 9, loop: false };
      case "victory":
        return { frames: a.victory, fps: 3, loop: true };
      case "morph":
        // 2 civilian frames: morpher at the chest → arm to the sky (switch at MORPH_ARM_UP)
        return { frames: a.morph, fps: 1 / MORPH_ARM_UP, loop: false };
      default:
        return { frames: a.idle, fps: 4, loop: true };
    }
  }

  frameIndex(): number {
    const an = this.currentAnim();
    const i = Math.floor(this.t * an.fps);
    return an.loop ? i % an.frames.length : Math.min(i, an.frames.length - 1);
  }

  animDone(): boolean {
    const an = this.currentAnim();
    return !an.loop && this.t * an.fps >= an.frames.length;
  }

  feetY(): number {
    return GROUND_TOP + this.z * ZPX;
  }
}

/* ---------------- world objects / fx ---------------- */

interface StageObj {
  kind: ObjKind;
  x: number;
  z: number;
  w: number;
  zr: number;
  hp: number;
  vx: number;
  rot: number;
  timer: number;
  up: boolean;
  warn: boolean;
  cool: Map<Fighter, number>;
  dead: boolean;
  wobble: number;
}

interface Spark {
  x: number;
  y: number;
  t: number;
  big: boolean;
}
interface Floater {
  x: number;
  y: number;
  txt: string;
  color: string;
  t: number;
}
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  t: number;
  life: number;
  color: string;
  size: number;
  grav: number;
}
interface Pickup {
  x: number;
  z: number;
  t: number;
  heal: number;
}
interface Hazard {
  type: HazardType;
  x: number;
  z: number;
  t: number;
  warnT: number;
  activeT: number;
  dmg: number;
  hitDone: Set<Fighter>;
}

export interface EngineCallbacks {
  onGameOver: (score: number) => void;
  onVictory: (score: number) => void;
}

export type TouchAction = "punch" | "kick" | "special" | "jump" | "morph";

const RANGER_GLOW: Record<CharKey, string> = {
  red: "#ff4a3a",
  blue: "#4a7dff",
  black: "#9a9ab8",
  pink: "#ff7ac2",
  yellow: "#ffe24a",
  white: "#ffffff",
};

/* ---------------- game ---------------- */

export class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  player: Fighter;
  enemies: Fighter[] = [];
  objects: StageObj[] = [];
  pickups: Pickup[] = [];
  particles: Particle[] = [];
  sparks: Spark[] = [];
  floaters: Floater[] = [];
  hazards: Hazard[] = [];
  hazardTimer = 0;
  ambientT = 0;
  keys = new Set<string>();
  camX = 0;
  score = 0;
  phase = 0;
  wave = 0;
  toSpawn = 0;
  spawnT = 0;
  bannerT = 0;
  bannerBig = "";
  bannerSmall = "";
  specialCd = 0;
  shake = 0;
  hitstop = 0;
  over = false;
  raf = 0;
  last = 0;
  time = 0;
  cb: EngineCallbacks;
  charKey: CharKey;
  comboStep = 0;
  comboTimer = 0;
  endT = -1;
  phaseEndT = -1;
  worldW = 2000;
  morphed = false;
  morphMeter = 0;
  morphT = -1;
  morphThunder = false;
  flashT = 0;

  constructor(canvas: HTMLCanvasElement, charKey: CharKey, cb: EngineCallbacks) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    this.ctx.imageSmoothingEnabled = false;
    this.cb = cb;
    this.charKey = charKey;
    this.player = new Fighter(CIV_SHEET[charKey], buildCivAnims(charKey), 120, 180, true);
    this.startPhase(0);
    this.onKeyDown = this.onKeyDown.bind(this);
    this.onKeyUp = this.onKeyUp.bind(this);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
  }

  stage(): StageDef {
    return STAGES[this.phase];
  }

  startPhase(i: number) {
    this.phase = i;
    const st = STAGES[i];
    this.worldW = st.imgW * 2;
    this.enemies = [];
    this.sparks = [];
    this.floaters = [];
    this.hazards = [];
    this.pickups = [];
    this.particles = [];
    this.hazardTimer = 2.5;
    this.camX = 0;
    const p = this.player;
    p.x = 180;
    p.z = 0.5;
    p.h = 0;
    p.vy = 0;
    p.vx = 0;
    p.mvx = 0;
    p.mvz = 0;
    p.facing = 1;
    p.setState("idle");
    this.objects = st.objects.map((d) => ({
      kind: d.kind,
      x: d.x * this.worldW,
      z: d.z,
      w: OBJ_SIZE[d.kind].w,
      zr: OBJ_SIZE[d.kind].zr,
      hp: d.kind === "crate" ? 3 : 999,
      vx: 0,
      rot: 0,
      timer: Math.random() * 2,
      up: false,
      warn: false,
      cool: new Map(),
      dead: false,
      wobble: 0,
    }));
    if (i > 0) {
      p.hp = Math.min(p.maxHp, p.hp + 45);
      sfx.wave();
    }
    this.wave = -1;
    this.toSpawn = 0;
    this.banner(`FASE ${i + 1}`, st.name, 2.6);
    this.spawnT = 1.4;
    this.nextWave();
  }

  nextWave() {
    const st = this.stage();
    this.wave++;
    if (this.wave < st.waves.length) {
      this.toSpawn = st.waves[this.wave];
      this.spawnT = Math.max(this.spawnT, 0.6);
      if (this.wave > 0) {
        this.banner(`ONDA ${this.wave + 1}`, "Mais inimigos chegando!", 1.8);
        sfx.wave();
      }
    }
  }

  banner(big: string, small: string, t: number) {
    this.bannerBig = big;
    this.bannerSmall = small;
    this.bannerT = t;
  }

  /* ---------- input ---------- */

  onKeyDown(e: KeyboardEvent) {
    const k = e.key.toLowerCase();
    if (
      ["arrowup", "arrowdown", "arrowleft", "arrowright", " ", "z", "x", "c", "j", "k", "l", "m", "enter"].includes(k)
    )
      e.preventDefault();
    this.keys.add(k);
    if (k === "z" || k === "j") this.action("punch");
    else if (k === "x" || k === "k") this.action("kick");
    else if (k === "c" || k === "l") this.action("special");
    else if (k === "m" || k === "enter") this.action("morph");
    else if (k === " ") this.action("jump");
  }

  onKeyUp(e: KeyboardEvent) {
    this.keys.delete(e.key.toLowerCase());
  }

  press(dir: string) {
    this.keys.add("arrow" + dir);
  }
  release(dir: string) {
    this.keys.delete("arrow" + dir);
  }

  action(a: TouchAction) {
    const p = this.player;
    if (this.over || p.dead || this.morphT >= 0) return;
    const busy = ["attack", "special", "hurt", "fall", "down", "getup", "victory", "morph"].includes(p.state);
    switch (a) {
      case "morph":
        if (!this.morphed && this.morphMeter >= 1 && !busy && p.h <= 0) this.doMorph();
        break;
      case "punch":
        if (!busy && p.state !== "jump") this.doAttack("punch");
        break;
      case "kick":
        if (!busy) this.doAttack("kick");
        break;
      case "special":
        if (!busy && p.state !== "jump" && this.specialCd <= 0 && this.morphed)
          this.doAttack("special");
        break;
      case "jump":
        if (!busy && p.state !== "jump" && p.h <= 0) {
          p.vy = -820;
          p.h = 0.001;
          p.setState("jump");
          sfx.jump();
        }
        break;
    }
  }

  /* Cinematic morph sequence (world frozen, letterbox + camera zoom):
       0.0–0.9s  civilian raises the morpher to the chest  ("IT'S MORPHIN TIME!")
       0.9–1.7s  arm thrust to the sky, lightning builds up, aura grows
       1.7s      thunder strike → white flash → sprite becomes the Ranger
       1.7–2.9s  Ranger holds the pose, dino call caption, power-up sting */
  doMorph() {
    const p = this.player;
    this.morphT = MORPH_DUR;
    this.morphThunder = false;
    p.setState("morph");
    p.facing = 1;
    p.vx = 0;
    p.mvx = 0;
    p.mvz = 0;
    sfx.morphin();
  }

  morphElapsed(): number {
    return this.morphT >= 0 ? MORPH_DUR - this.morphT : -1;
  }

  morphCall(): string {
    switch (this.charKey) {
      case "red": return "TIRANOSSAURO!";
      case "black": return "MASTODONTE!";
      case "blue": return "TRICERÁTOPS!";
      case "yellow": return "DENTE-DE-SABRE!";
      case "pink": return "PTERODÁCTILO!";
      case "white": return "TIGRE BRANCO!";
    }
  }

  rangerName(): string {
    switch (this.charKey) {
      case "red": return "RANGER VERMELHO";
      case "black": return "RANGER PRETO";
      case "blue": return "RANGER AZUL";
      case "yellow": return "RANGER AMARELA";
      case "pink": return "RANGER ROSA";
      case "white": return "RANGER BRANCO";
    }
  }

  doAttack(kind: "punch" | "kick" | "special") {
    const p = this.player;
    const a = p.anims;
    const civ = !this.morphed;
    if (kind === "punch") {
      // Combo: punch1 → punch2 → punch3, escalating damage; resets after ~0.7s
      this.comboStep = (this.comboStep + 1) % 4;
      let frames: Frame[];
      let dmg: number, range: number, kd: boolean;
      if (this.comboStep === 1) { frames = a.punch; dmg = civ ? 5 : 7; range = 72; kd = false; }
      else if (this.comboStep === 2) { frames = a.punch2; dmg = civ ? 7 : 10; range = 80; kd = false; }
      else if (this.comboStep === 3) { frames = a.punch3; dmg = civ ? 11 : 16; range = 92; kd = true; this.comboStep = 0; }
      else { frames = a.punch; dmg = civ ? 5 : 7; range = 72; kd = false; }
      p.attack = {
        anim: { frames, fps: 9, loop: false },
        hitFrame: Math.min(1, frames.length - 1),
        dmg, range, knockdown: kd,
      };
      p.setState("attack");
      sfx.punch();
      this.comboTimer = 0.7;
    } else if (kind === "kick") {
      // Air kick = dive (carry forward)
      if (p.state === "jump") {
        p.attack = {
          anim: { frames: [a.kick[Math.min(1, a.kick.length - 1)]], fps: 5, loop: false },
          hitFrame: 0,
          dmg: civ ? 12 : 17,
          range: 96,
          knockdown: true,
        };
        p.setState("attack");
        // forward momentum so the dive travels
        if (Math.abs(p.vx) < 60) p.vx = p.facing * 90;
        // cancel horizontal momentum while attack animates so we don't fly
        p.mvx = 0;
        sfx.kick();
        return;
      }
      p.attack = {
        anim: { frames: a.kick, fps: 8, loop: false },
        hitFrame: Math.min(1, a.kick.length - 1),
        dmg: civ ? 11 : 16,
        range: civ ? 86 : 98,
        knockdown: true,
      };
      p.setState("attack");
      sfx.kick();
      this.comboStep = 0;
    } else {
      // Personalized weapon: per-ranger frames + per-ranger FX
      const wFrames = getWeaponFrames(this.charKey);
      const spec = WEAPON_SPECS[this.charKey];
      const animFrames = wFrames.length ? wFrames : a.special;
      p.attack = {
        anim: { frames: animFrames, fps: 6, loop: false },
        hitFrame: Math.min(spec.hitFrame, animFrames.length - 1),
        dmg: civ ? Math.floor(spec.dmg * 0.7) : spec.dmg,
        range: spec.range,
        knockdown: true,
        aoe: spec.aoe,
        weaponFx: spec.fx,
      };
      p.setState("special");
      this.specialCd = 5;
      this.shake = 0.32;
      sfx.special();
      this.comboStep = 0;
    }
  }

  /* ---------- spawning ---------- */

  spawnEnemy() {
    const st = this.stage();
    const pool = st.enemies;
    let kind: EnemyKind = "putty";
    if (pool.length > 1 && Math.random() < 0.35) {
      const specials = pool.filter((k) => k !== "putty");
      kind = specials[Math.floor(Math.random() * specials.length)];
    }
    const diff = this.phase * 1.5 + this.wave;
    let hp = 24 + diff * 6;
    let speed = 60 + diff * 5 + Math.random() * 18;
    if (kind === "skelerena") {
      hp *= 0.7;
      speed = 110 + diff * 5;
    } else if (kind === "oozeman") {
      hp *= 1.9;
      speed = 38 + diff * 2;
    }
    const e = new Fighter(kind, buildEnemyAnims(kind), hp, speed, false);
    e.kind = kind;
    const side = Math.random() < 0.5 ? -1 : 1;
    e.x = this.camX + (side < 0 ? -60 : VIEW_W + 60);
    e.x = Math.max(-80, Math.min(this.worldW + 80, e.x));
    e.z = Math.random();
    e.attackCd = 0.8 + Math.random() * 1.6;
    this.enemies.push(e);
  }

  spawnHazard() {
    const st = this.stage();
    if (!st.hazard) return;
    const type = st.hazard.type;
    const h: Hazard = {
      type,
      x: this.camX + 120 + Math.random() * (VIEW_W - 240),
      z: 0.15 + Math.random() * 0.7,
      t: 0,
      warnT: type === "girder" ? 1.1 : 0.9,
      activeT: type === "girder" ? 0.35 : 2.2,
      dmg: st.hazard.dmg,
      hitDone: new Set(),
    };
    if (Math.random() < 0.45) {
      h.x = this.player.x + (Math.random() - 0.5) * 160;
      h.z = Math.max(Z_MIN, Math.min(Z_MAX, this.player.z + (Math.random() - 0.5) * 0.3));
    }
    h.x = Math.max(40, Math.min(this.worldW - 40, h.x));
    this.hazards.push(h);
  }

  /* ---------- helpers ---------- */

  addFloater(x: number, y: number, txt: string, color: string) {
    this.floaters.push({ x, y, txt, color, t: 0 });
  }

  burst(x: number, y: number, color: string, n: number, speed: number, grav = 900, size = 4) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = speed * (0.4 + Math.random() * 0.8);
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s - speed * 0.5,
        t: 0,
        life: 0.5 + Math.random() * 0.5,
        color,
        size: size * (0.6 + Math.random() * 0.8),
        grav,
      });
    }
  }

  /** apply damage + airborne launch to any fighter */
  damage(f: Fighter, dmg: number, dirX: number, knockdown: boolean, launch = 380, source = "hit") {
    f.hp -= dmg;
    f.hitFlash = 0.14;
    f.vx = dirX * (knockdown ? 240 : 140);
    const color = f.isPlayer ? "#ff6b6b" : source === "trap" ? "#ff9d4a" : "#ffe26b";
    this.addFloater(f.x, f.feetY() - f.h - 84 - Math.random() * 16, (f.isPlayer ? "-" : "") + dmg, color);
    if (f.isPlayer) sfx.hurt();
    if (f.hp <= 0 || knockdown) {
      if (f.isPlayer && f.hp <= 0) f.hp = 0;
      f.setState("fall");
      f.vy = -launch;
      f.h = Math.max(f.h, 0.001);
      if (!f.isPlayer) sfx.fall();
      this.hitstop = Math.max(this.hitstop, 0.08);
      this.shake = Math.max(this.shake, 0.16);
    } else {
      f.setState("hurt");
      if (!f.isPlayer) sfx.hitConnect();
      this.hitstop = Math.max(this.hitstop, 0.05);
    }
    if (f.isPlayer) f.invuln = Math.max(f.invuln, knockdown ? 0.6 : 0.35);
  }

  /* ---------- main loop ---------- */

  loop = (now: number) => {
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    this.update(dt);
    this.render();
    this.raf = requestAnimationFrame(this.loop);
  };

  update(dt: number) {
    this.time += dt;
    if (this.hitstop > 0) {
      this.hitstop -= dt;
      this.shake = Math.max(0, this.shake - dt * 0.5);
      return;
    }
    const p = this.player;
    this.specialCd = Math.max(0, this.specialCd - dt);
    this.bannerT -= dt;
    this.shake = Math.max(0, this.shake - dt);
    this.flashT = Math.max(0, this.flashT - dt);
    p.t += dt;
    p.invuln = Math.max(0, p.invuln - dt);
    p.hitFlash = Math.max(0, p.hitFlash - dt);
    this.updateAmbient(dt);
    this.updateParticles(dt);

    // morph cinematic: morpher at chest → arm to the sky + lightning → strike → Ranger
    if (this.morphT >= 0) {
      this.morphT -= dt;
      const el = this.morphElapsed();
      // rumble builds while the lightning charges
      if (el > MORPH_ARM_UP && el < MORPH_STRIKE) this.shake = Math.max(this.shake, 0.08 + (el - MORPH_ARM_UP) * 0.25);
      if (el >= MORPH_ARM_UP && !this.morphThunder) {
        this.morphThunder = true;
        sfx.thunder();
      }
      if (el >= MORPH_STRIKE && !this.morphed) {
        this.morphed = true;
        p.sheet = RANGER_SHEET[this.charKey];
        p.anims = buildAnims(this.charKey);
        p.setState("victory");
        p.hp = p.maxHp;
        p.speed = 200;
        p.invuln = 1.6;
        this.flashT = 0.55;
        this.shake = 0.6;
        sfx.powerUp();
        this.burst(p.x, p.feetY() - 60, RANGER_GLOW[this.charKey], 48, 460, 300, 5);
        this.burst(p.x, p.feetY() - 60, "#ffffff", 20, 300, 200, 3);
      }
      if (this.morphT <= 0) {
        this.morphT = -1;
        p.setState("idle");
        this.banner(this.rangerName(), "Poder total! Arma liberada [C]", 1.6);
      }
      return;
    }

    // waves / phases
    if (this.toSpawn > 0) {
      this.spawnT -= dt;
      if (this.spawnT <= 0 && this.enemies.length < 6) {
        this.spawnEnemy();
        this.toSpawn--;
        this.spawnT = 1.0 + Math.random() * 1.1;
      }
    } else if (this.enemies.length === 0 && !this.over && this.endT < 0 && this.phaseEndT < 0) {
      const st = this.stage();
      if (this.wave + 1 < st.waves.length) this.nextWave();
      else if (this.phase + 1 < STAGES.length) {
        this.phaseEndT = 2.2;
        this.banner("FASE CONCLUÍDA!", "Teletransportando…", 2.2);
        p.setState("victory");
        sfx.victory();
      } else {
        this.endT = 2.6;
        p.setState("victory");
        sfx.victory();
      }
    }
    if (this.phaseEndT > 0) {
      this.phaseEndT -= dt;
      if (this.phaseEndT <= 0) {
        this.phaseEndT = -1;
        this.startPhase(this.phase + 1);
      }
    }
    if (this.endT > 0) {
      this.endT -= dt;
      if (this.endT <= 0) {
        this.over = true;
        this.cb.onVictory(this.score);
      }
    }
    this.comboTimer = Math.max(0, this.comboTimer - dt);
    if (this.comboTimer <= 0 && this.comboStep > 0 && p.state !== "attack") this.comboStep = 0;

    this.updateHazards(dt);

    // ---- player control (with momentum on ooze) ----
    p.onOoze = this.onOoze(p);
    if (!this.over && !p.dead && this.phaseEndT < 0) {
      const k = this.keys;
      const left = k.has("arrowleft") || k.has("a");
      const right = k.has("arrowright") || k.has("d");
      const up = k.has("arrowup") || k.has("w");
      const dn = k.has("arrowdown") || k.has("s");
      const canMove = ["idle", "walk", "jump"].includes(p.state);
      const dx = canMove ? (right ? 1 : 0) - (left ? 1 : 0) : 0;
      const dz = canMove ? (dn ? 1 : 0) - (up ? 1 : 0) : 0;
      const tx = dx * p.speed;
      const tz = dz * 1.15;
      if (p.onOoze && p.h <= 0) {
        // slippery: slow response, keeps sliding
        p.mvx += (tx - p.mvx) * Math.min(1, 1.6 * dt);
        p.mvz += (tz - p.mvz) * Math.min(1, 1.6 * dt);
        if (Math.abs(p.mvx) > 60 && Math.random() < 0.3)
          this.particles.push({
            x: p.x - Math.sign(p.mvx) * 10,
            y: p.feetY(),
            vx: -p.mvx * 0.2,
            vy: -60,
            t: 0,
            life: 0.35,
            color: "#b27ae6",
            size: 3,
            grav: 500,
          });
      } else {
        p.mvx = tx;
        p.mvz = tz;
      }
      if (canMove) {
        if (dx) p.facing = dx;
        p.x += p.mvx * dt;
        p.z += p.mvz * dt;
        if (p.state !== "jump") p.setState(dx || dz || Math.abs(p.mvx) > 25 ? "walk" : "idle");
      }
    }
    if (["hurt", "fall"].includes(p.state)) {
      p.x += p.vx * dt;
      if (p.h <= 0) p.vx *= 1 - 4 * dt;
      p.mvx *= 1 - 5 * dt; // bleed momentum so player doesn't drift while hurt
    }
    this.integrateAir(p, dt);
    this.clampWorld(p);

    // player attacks
    if ((p.state === "attack" || p.state === "special") && p.attack && !p.didHit) {
      if (p.frameIndex() >= p.attack.hitFrame) {
        p.didHit = true;
        this.resolveHit(p, this.enemies, p.attack);
        this.hitObjects(p, p.attack);
      }
    }
    if ((p.state === "attack" || p.state === "special") && p.animDone() && p.h <= 0 && p.attack) {
      p.attack = null;
      p.setState("idle");
    }
    if (p.state === "hurt" && p.animDone()) p.setState("idle");
    if (p.state === "fall" && p.animDone() && p.h <= 0) {
      if (p.hp <= 0) {
        p.dead = true;
        p.setState("dead");
      } else p.setState("down");
      p.downT = 0.7;
    }
    if (p.state === "down") {
      p.downT -= dt;
      if (p.downT <= 0) p.setState("getup");
    }
    if (p.state === "getup" && p.animDone()) {
      p.invuln = 0.8;
      p.setState("idle");
    }
    if (p.state === "dead" && !this.over && p.animDone() && p.t > 1.6) {
      this.over = true;
      sfx.gameover();
      this.cb.onGameOver(this.score);
    }

    // ---- enemies ----
    for (const e of this.enemies) {
      e.t += dt;
      e.invuln = Math.max(0, e.invuln - dt);
      e.flicker = Math.max(0, e.flicker - dt);
      e.hitFlash = Math.max(0, e.hitFlash - dt);
      e.blockT = Math.max(0, e.blockT - dt);
      if (e.removeT > 0) {
        e.removeT -= dt;
        continue;
      }
      if (e.knocked()) {
        e.x += e.vx * dt;
        if (e.h <= 0) e.vx *= 1 - 4 * dt;
        this.integrateAir(e, dt);
        this.clampWorld(e);
        if (e.state === "hurt" && e.animDone()) e.setState("idle");
        if (e.state === "fall" && e.animDone() && e.h <= 0) {
          if (e.hp <= 0) {
            e.removeT = 0.8;
            e.flicker = 0.8;
            this.score += e.kind === "putty" ? 100 : 250;
            if (e.kind === "oozeman" && Math.random() < 0.35)
              this.pickups.push({ x: e.x, z: e.z, t: 0, heal: 25 });
            continue;
          }
          e.setState("down");
          e.downT = 0.8 + Math.random() * 0.5;
        }
        if (e.state === "down") {
          e.downT -= dt;
          if (e.downT <= 0) e.setState("getup");
        }
        if (e.state === "getup" && e.animDone()) {
          e.invuln = 0.5;
          e.setState("idle");
        }
        continue;
      }
      if (this.over || p.dead || p.state === "victory" || this.phaseEndT > 0) {
        e.setState("idle");
        continue;
      }
      e.attackCd -= dt;
      const dx = p.x - e.x;
      const dz = (p.z - e.z) * 110;
      const adx = Math.abs(dx);
      const adz = Math.abs(dz);
      e.facing = dx >= 0 ? 1 : -1;
      if (e.state === "attack") {
        if (e.attack?.lungeSpeed) e.x += e.facing * e.attack.lungeSpeed * dt;
        if (e.attack && !e.didHit && e.frameIndex() >= e.attack.hitFrame) {
          e.didHit = true;
          this.resolveEnemyHit(e);
        }
        if (e.animDone()) {
          e.attack = null;
          e.setState("idle");
          e.attackCd =
            (e.kind === "skelerena" ? 1.6 : e.kind === "oozeman" ? 1.8 : 1.2) + Math.random() * 1.4;
        }
        continue;
      }
      const reach = e.kind === "oozeman" ? 105 : e.kind === "skelerena" ? 95 : 74;
      if (adx < reach && adz < 26) {
        if (e.attackCd <= 0) {
          const dmgBase = e.kind === "oozeman" ? 10 : e.kind === "skelerena" ? 8 : 6;
          e.attack = {
            anim: { frames: e.anims.punch, fps: e.kind === "oozeman" ? 4 : 6, loop: false },
            hitFrame: Math.min(
              e.kind === "putty" || (e.kind === "skelerena" && skelerenaIsFallback()) ? 2 : 1,
              e.anims.punch.length - 1
            ),
            dmg: dmgBase + Math.floor(this.phase * 1.5) + this.wave,
            range: e.kind === "oozeman" ? 118 : e.kind === "skelerena" ? 104 : 86,
            knockdown: e.kind !== "putty",
            lungeSpeed: e.kind === "skelerena" ? 130 : 0,
          };
          e.setState("attack");
        } else e.setState("idle");
      } else {
        const tx = p.x - e.facing * 55;
        let mx = Math.sign(tx - e.x);
        let mz = Math.sign(p.z - e.z);
        if (e.blockT > 0) {
          // detour around a solid object
          mz = e.blockDir;
          mx *= 0.35;
        }
        const spd = e.speed * (this.onOoze(e) ? 0.55 : 1);
        e.x += mx * spd * dt;
        e.z += mz * (e.kind === "skelerena" ? 0.85 : 0.6) * dt;
        e.z = Math.max(Z_MIN, Math.min(Z_MAX, e.z));
        e.x = Math.max(10, Math.min(this.worldW - 10, e.x));
        e.setState("walk");
      }
    }
    this.enemies = this.enemies.filter((e) => e.removeT === -1 || e.removeT > 0);

    this.updateObjects(dt);
    this.updatePickups(dt);

    for (const s of this.sparks) s.t += dt;
    this.sparks = this.sparks.filter((s) => s.t < 0.3);
    for (const f of this.floaters) f.t += dt;
    this.floaters = this.floaters.filter((f) => f.t < 0.8);

    const target = Math.max(0, Math.min(this.worldW - VIEW_W, p.x - VIEW_W / 2));
    this.camX += (target - this.camX) * Math.min(1, 6 * dt);
  }

  clampWorld(f: Fighter) {
    const minX = f.isPlayer ? 30 : 10;
    const maxX = this.worldW - minX;
    if (f.x < minX) {
      f.x = minX;
      if (f.state === "fall" && f.vx < -80) {
        f.vx = -f.vx * 0.45; // bounce off the world edge
        this.shake = Math.max(this.shake, 0.1);
      } else f.vx = Math.max(0, f.vx);
    } else if (f.x > maxX) {
      f.x = maxX;
      if (f.state === "fall" && f.vx > 80) {
        f.vx = -f.vx * 0.45;
        this.shake = Math.max(this.shake, 0.1);
      } else f.vx = Math.min(0, f.vx);
    }
    f.z = Math.max(Z_MIN, Math.min(Z_MAX, f.z));
  }

  integrateAir(f: Fighter, dt: number) {
    if (f.state === "jump" || f.h > 0) {
      f.vy += GRAV * dt;
      f.h += -f.vy * dt;
      if (f.h <= 0) {
        f.h = 0;
        if (f.state === "fall" && f.vy > 260) {
          // bounce on landing, dust puff
          f.vy = -f.vy * 0.32;
          f.h = 0.001;
          this.burst(f.x, f.feetY(), "#cbb89a", 6, 90, 400, 3);
          this.shake = Math.max(this.shake, 0.08);
          return;
        }
        f.vy = 0;
        if (f.state === "jump") f.setState("idle");
        else if (f.state === "attack") {
          f.attack = null;
          f.setState("idle");
        }
      }
    }
  }

  /* ---------- stage objects ---------- */

  /** zr is the half-depth (radius) of the object in world z-units; padZ is the
      extra body radius of the fighter (same value pushOut resolves against). */
  overlaps(f: Fighter, o: StageObj, padX = 14, padZ = 0.06): boolean {
    return Math.abs(f.x - o.x) < o.w + padX && Math.abs(f.z - o.z) < o.zr + padZ;
  }

  onOoze(f: Fighter): boolean {
    if (f.h > 0) return false;
    for (const o of this.objects)
      if (o.kind === "ooze" && !o.dead && this.overlaps(f, o, 0, 0)) return true;
    return false;
  }

  isSolid(o: StageObj): boolean {
    if (o.dead) return false;
    if (o.kind === "crate" || o.kind === "firebarrel") return true;
    if (o.kind === "barrel") return Math.abs(o.vx) < 40;
    return false;
  }

  /** push a fighter out of a solid footprint */
  pushOut(f: Fighter, o: StageObj): "x" | "z" | null {
    if (!this.overlaps(f, o)) return null;
    const dx = f.x - o.x;
    const dz = f.z - o.z;
    const ox = o.w + 14 - Math.abs(dx);
    const oz = (o.zr + 0.06 - Math.abs(dz)) * ZPX;
    if (ox < oz) {
      f.x += (dx >= 0 ? 1 : -1) * ox;
      return "x";
    }
    f.z += (dz >= 0 ? 1 : -1) * (oz / ZPX);
    return "z";
  }

  updateObjects(dt: number) {
    const p = this.player;
    const fighters: Fighter[] = [p, ...this.enemies.filter((e) => e.removeT === -1)];
    for (const o of this.objects) {
      if (o.dead) continue;
      for (const [f, c] of o.cool) {
        const n = c - dt;
        if (n <= 0) o.cool.delete(f);
        else o.cool.set(f, n);
      }
      o.wobble = Math.max(0, o.wobble - dt);

      // retractable spikes cycle: down 2.2s → warning 0.6s → up 1.4s
      if (o.kind === "retract") {
        o.timer += dt;
        const c = o.timer % 4.2;
        const wasUp = o.up;
        o.warn = c >= 2.2 && c < 2.8;
        o.up = c >= 2.8;
        if (o.up && !wasUp) sfx.kick();
      }

      // rolling barrel physics
      if (o.kind === "barrel" && Math.abs(o.vx) >= 40) {
        o.x += o.vx * dt;
        o.rot += (o.vx / 22) * dt;
        o.vx *= 1 - 0.9 * dt;
        if (o.x < 30 || o.x > this.worldW - 30) {
          o.x = Math.max(30, Math.min(this.worldW - 30, o.x));
          o.vx = -o.vx * 0.5;
          sfx.kick();
        }
        // smash enemies in its path
        for (const e of this.enemies) {
          if (e.removeT !== -1 || e.invuln > 0 || e.knocked()) continue;
          if (this.overlaps(e, o, 18, 0.05)) {
            this.damage(e, 18, Math.sign(o.vx) || 1, true, 420);
            this.sparks.push({ x: e.x, y: e.feetY() - 50, t: 0, big: true });
            this.score += 25;
            if (!this.morphed) this.morphMeter = Math.min(1, this.morphMeter + 0.1);
            o.vx *= 0.7;
          }
        }
        // rolling barrel also breaks crates
        for (const c of this.objects) {
          if (c.kind === "crate" && !c.dead && Math.abs(c.x - o.x) < c.w + o.w && Math.abs(c.z - o.z) < c.zr + o.zr) {
            this.breakCrate(c);
            o.vx *= 0.5;
          }
        }
        if (Math.abs(o.vx) < 40) o.vx = 0;
      }

      for (const f of fighters) {
        if (f.state === "dead") continue;
        const grounded = f.h < 10;
        const airborneOver = f.h > 40;

        // solids: block movement (jumping over is allowed)
        if (this.isSolid(o) && !airborneOver) {
          const axis = this.pushOut(f, o);
          if (axis && !f.knocked()) {
            if (!f.isPlayer && f.blockT <= 0) {
              f.blockT = 0.55;
              f.blockDir = f.z < o.z ? -1 : 1;
              if ((f.z < 0.12 && f.blockDir < 0) || (f.z > 0.88 && f.blockDir > 0)) f.blockDir *= -1;
            } else if (f.isPlayer) {
              // player gets a tiny grace period so they don't feel stuck
              if (f.blockT <= 0) f.blockT = 0.18;
            }
          }
          // a fighter knocked into a solid object: bounce back
          if (axis === "x" && f.state === "fall" && Math.abs(f.vx) > 120) {
            f.vx = -f.vx * 0.5;
            if (o.kind === "crate") this.breakCrateHit(o, 1);
            if (o.kind === "barrel") o.vx = Math.sign(f.x < o.x ? 1 : -1) * 260;
          }
        }

        // spikes / retractable spikes: damage on ground contact
        if ((o.kind === "spikes" || (o.kind === "retract" && o.up)) && grounded) {
          if (!f.isPlayer && !f.knocked()) {
            // walking enemies treat spikes as a solid they avoid
            const axis = this.pushOut(f, o);
            if (axis && f.blockT <= 0) {
              f.blockT = 0.5;
              f.blockDir = f.z < o.z ? -1 : 1;
            }
          } else if (this.overlaps(f, o, 4, 0.02) && !o.cool.has(f) && f.invuln <= 0) {
            o.cool.set(f, 1.2);
            const dir = f.x >= o.x ? 1 : -1;
            this.damage(f, f.isPlayer ? 12 : 10, dir, true, 470, "trap");
            f.vx = dir * 300;
            this.sparks.push({ x: f.x, y: f.feetY() - 20, t: 0, big: true });
            this.burst(f.x, f.feetY() - 10, "#e04040", 8, 140, 800, 3);
            if (!f.isPlayer) {
              this.score += 30;
              if (!this.morphed) this.morphMeter = Math.min(1, this.morphMeter + 0.1);
            }
          }
        }

        // fire drums: burn anyone grounded next to them (enemies only when knocked into it)
        if (o.kind === "firebarrel" && grounded && (f.isPlayer || f.knocked())) {
          if (this.overlaps(f, o, 26, 0.09) && !o.cool.has(f) && f.invuln <= 0 && f.state !== "down" && f.state !== "getup") {
            o.cool.set(f, 1.0);
            const dir = f.x >= o.x ? 1 : -1;
            this.damage(f, f.isPlayer ? 10 : 12, dir, true, 400, "trap");
            f.vx = dir * 260;
            this.burst(f.x, f.feetY() - 50, "#ff8c2e", 10, 160, 200, 4);
            if (!f.isPlayer) this.score += 30;
          }
        }
      }
    }
  }

  breakCrateHit(o: StageObj, dmg: number) {
    o.hp -= dmg;
    o.wobble = 0.25;
    this.burst(o.x, this.objY(o) - 30, "#b07a3a", 5, 120, 900, 3);
    sfx.punch();
    if (o.hp <= 0) this.breakCrate(o);
  }

  breakCrate(o: StageObj) {
    if (o.dead) return;
    o.dead = true;
    this.burst(o.x, this.objY(o) - 30, "#a86a2c", 18, 220, 900, 5);
    this.burst(o.x, this.objY(o) - 30, "#e0b070", 10, 180, 900, 3);
    this.shake = Math.max(this.shake, 0.15);
    sfx.fall();
    this.pickups.push({ x: o.x, z: o.z, t: 0, heal: 30 });
    this.score += 50;
  }

  objY(o: StageObj): number {
    return GROUND_TOP + o.z * ZPX;
  }

  /** player attacks interact with crates and barrels */
  hitObjects(attacker: Fighter, atk: AttackSpec) {
    for (const o of this.objects) {
      if (o.dead) continue;
      if (o.kind !== "crate" && o.kind !== "barrel") continue;
      const dx = o.x - attacker.x;
      const inFront = atk.aoe ? Math.abs(dx) < atk.range : dx * attacker.facing > -10 && Math.abs(dx) < atk.range + o.w;
      const dz = Math.abs(o.z - attacker.z) * 110;
      if (!inFront || dz > 30) continue;
      if (o.kind === "crate") {
        this.breakCrateHit(o, atk.aoe ? 3 : 1);
        this.sparks.push({ x: o.x, y: this.objY(o) - 30, t: 0, big: false });
        this.hitstop = Math.max(this.hitstop, 0.04);
      } else {
        // kick sends the barrel rolling, punch nudges it
        const power = atk.knockdown ? 560 : 300;
        o.vx = attacker.facing * power;
        o.wobble = 0.2;
        this.sparks.push({ x: o.x, y: this.objY(o) - 30, t: 0, big: atk.knockdown });
        sfx.kick();
      }
    }
  }

  updatePickups(dt: number) {
    const p = this.player;
    for (const it of this.pickups) {
      it.t += dt;
      if (p.dead) continue;
      if (Math.abs(p.x - it.x) < 26 && Math.abs(p.z - it.z) < 0.1 && p.h < 20) {
        it.t = 999;
        p.hp = Math.min(p.maxHp, p.hp + it.heal);
        this.addFloater(p.x, p.feetY() - 90, "+" + it.heal, "#7bf26b");
        this.burst(p.x, p.feetY() - 40, "#ffe26b", 14, 160, -100, 3);
        sfx.select();
        this.score += 20;
      }
    }
    this.pickups = this.pickups.filter((it) => it.t < 14);
  }

  /* ---------- dynamic hazards ---------- */

  updateHazards(dt: number) {
    const p = this.player;
    const st = this.stage();
    if (st.hazard && !this.over && this.phaseEndT < 0) {
      this.hazardTimer -= dt;
      if (this.hazardTimer <= 0) {
        this.spawnHazard();
        const [a, b] = st.hazard.every;
        this.hazardTimer = a + Math.random() * (b - a);
      }
    }
    for (const h of this.hazards) {
      h.t += dt;
      const active = h.t > h.warnT && h.t < h.warnT + h.activeT;
      if (!active) continue;
      if (h.type === "girder" && h.t - dt <= h.warnT) {
        this.shake = Math.max(this.shake, 0.3);
        sfx.fall();
        this.burst(h.x, GROUND_TOP + h.z * ZPX, "#cbb89a", 12, 150, 500, 4);
      }
      const R = h.type === "girder" ? 46 : 52;
      const targets: Fighter[] = [p, ...this.enemies];
      for (const f of targets) {
        if (h.hitDone.has(f) || f.invuln > 0 || f.h > 40) continue;
        if (["fall", "down", "getup", "dead"].includes(f.state)) continue;
        const dx = Math.abs(f.x - h.x);
        const dz = Math.abs(f.z - h.z) * 110;
        if (dx < R && dz < 30) {
          h.hitDone.add(f);
          const dmg = f.isPlayer ? h.dmg : Math.ceil(h.dmg * 0.75);
          this.damage(f, dmg, f.x >= h.x ? 1 : -1, true, 420, "trap");
          this.sparks.push({ x: f.x, y: f.feetY() - 60, t: 0, big: true });
          if (!f.isPlayer) sfx.fall();
        }
      }
    }
    this.hazards = this.hazards.filter((h) => h.t < h.warnT + h.activeT + 0.4);
  }

  /* ---------- particles / ambient ---------- */

  updateParticles(dt: number) {
    for (const q of this.particles) {
      q.t += dt;
      q.vy += q.grav * dt;
      q.x += q.vx * dt;
      q.y += q.vy * dt;
    }
    this.particles = this.particles.filter((q) => q.t < q.life);
  }

  updateAmbient(dt: number) {
    const st = this.stage();
    if (st.ambient === "none") return;
    this.ambientT -= dt;
    if (this.ambientT > 0) return;
    this.ambientT = st.ambient === "embers" ? 0.06 : 0.16;
    const x = this.camX + Math.random() * VIEW_W;
    if (st.ambient === "embers")
      this.particles.push({ x, y: VIEW_H + 4, vx: (Math.random() - 0.5) * 30, vy: -60 - Math.random() * 70, t: 0, life: 3 + Math.random() * 2, color: Math.random() < 0.5 ? "#ff9a3a" : "#ffd36b", size: 2 + Math.random() * 2, grav: -10 });
    else if (st.ambient === "dust")
      this.particles.push({ x, y: Math.random() * VIEW_H, vx: 18 + Math.random() * 20, vy: (Math.random() - 0.5) * 8, t: 0, life: 4, color: "rgba(255,230,190,0.45)", size: 2, grav: 0 });
    else
      this.particles.push({ x, y: 40 + Math.random() * 240, vx: 0, vy: 0, t: 0, life: 1.2, color: "rgba(255,255,255,0.8)", size: 2, grav: 0 });
  }

  /* ---------- combat resolution ---------- */

  resolveHit(attacker: Fighter, targets: Fighter[], atk: AttackSpec) {
    let connected = false;
    for (const t of targets) {
      if (t.invuln > 0 || t.removeT > 0) continue;
      if (["fall", "down", "getup"].includes(t.state) && !atk.aoe) continue;
      const dx = t.x - attacker.x;
      const inFront = atk.aoe
        ? Math.abs(dx) < atk.range
        : dx * attacker.facing > -14 && Math.abs(dx) < atk.range;
      const dz = Math.abs(t.z - attacker.z) * 110;
      if (inFront && dz < 34) {
        connected = true;
        this.sparks.push({
          x: t.x + attacker.facing * 10,
          y: t.feetY() - 60 - Math.random() * 30,
          t: 0,
          big: atk.aoe === true || atk.knockdown,
        });
        if (!this.morphed) this.morphMeter = Math.min(1, this.morphMeter + 0.12);
        const willDie = t.hp - atk.dmg <= 0;
        this.damage(t, atk.dmg, attacker.facing, atk.knockdown, atk.aoe ? 520 : 380);
        if (!this.morphed && willDie) this.morphMeter = Math.min(1, this.morphMeter + 0.15);
        this.score += 10;
        if (!atk.aoe) break;
      }
    }
    if (connected && atk.aoe) {
      this.shake = 0.4;
      this.hitstop = Math.max(this.hitstop, 0.12);
    }
  }

  resolveEnemyHit(e: Fighter) {
    const p = this.player;
    if (!e.attack || p.invuln > 0 || p.dead) return;
    if (["fall", "down", "getup", "dead", "morph"].includes(p.state)) return;
    const dx = p.x - e.x;
    const dz = Math.abs(p.z - e.z) * 110;
    if (dx * e.facing > -14 && Math.abs(dx) < e.attack.range && dz < 34) {
      this.sparks.push({ x: p.x, y: p.feetY() - 70, t: 0, big: e.attack.knockdown });
      const kd = e.attack.knockdown || Math.random() < 0.18;
      this.damage(p, e.attack.dmg, e.facing, kd, 360);
      this.shake = Math.max(this.shake, 0.12);
    }
  }

  /* ================= rendering ================= */

  render() {
    const ctx = this.ctx;
    const st = this.stage();
    const shakeX = this.shake > 0 ? (Math.random() - 0.5) * 12 * this.shake : 0;
    const shakeY = this.shake > 0 ? (Math.random() - 0.5) * 8 * this.shake : 0;
    ctx.save();
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    ctx.translate(shakeX, shakeY);

    // cinematic camera: zoom toward the player while morphing
    const zoom = this.morphZoom();
    if (zoom > 1) {
      const px = this.player.x - this.camX;
      const py = this.player.feetY() - 60;
      ctx.translate(px, py);
      ctx.scale(zoom, zoom);
      ctx.translate(-px, -py);
    }

    const img = getImage(st.img);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, Math.round(-this.camX), 0, this.worldW, VIEW_H);
    if (this.morphT >= 0) {
      // dim the world so the hero pops
      ctx.fillStyle = "rgba(0,0,20,0.35)";
      ctx.fillRect(-VIEW_W, -VIEW_H, VIEW_W * 3, VIEW_H * 3);
    }

    const g = ctx.createLinearGradient(0, GROUND_TOP - 40, 0, VIEW_H);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, "rgba(0,0,0,0.28)");
    ctx.fillStyle = g;
    ctx.fillRect(0, GROUND_TOP - 40, VIEW_W, VIEW_H - GROUND_TOP + 40);

    // flat decals first
    for (const o of this.objects) if (o.kind === "ooze" && !o.dead) this.drawOoze(o);
    for (const h of this.hazards) this.drawHazardGround(h);

    // z-sorted world: fighters, solid objects, spikes, pickups
    type Item = { z: number; draw: () => void };
    const items: Item[] = [];
    for (const f of [...this.enemies, this.player]) items.push({ z: f.z, draw: () => this.drawFighter(f) });
    for (const o of this.objects) {
      if (o.dead || o.kind === "ooze") continue;
      items.push({ z: o.z - (o.kind === "spikes" || o.kind === "retract" ? 0.02 : 0), draw: () => this.drawObject(o) });
    }
    for (const it of this.pickups) items.push({ z: it.z, draw: () => this.drawPickup(it) });
    items.sort((a, b) => a.z - b.z);
    for (const it of items) it.draw();

    for (const h of this.hazards) this.drawHazardAir(h);

    // morph lightning
    if (this.morphT >= 0) this.drawMorphFx();

    // particles
    for (const q of this.particles) {
      const a = 1 - q.t / q.life;
      ctx.globalAlpha = Math.max(0, Math.min(1, a * 1.4));
      ctx.fillStyle = q.color;
      const px = Math.round(q.x - this.camX - q.size / 2);
      const py = Math.round(q.y - q.size / 2);
      ctx.fillRect(px, py, Math.max(1, Math.round(q.size)), Math.max(1, Math.round(q.size)));
    }
    ctx.globalAlpha = 1;

    for (const s of this.sparks) {
      const sx = s.x - this.camX;
      const pr = s.t / 0.3;
      const r = (s.big ? 34 : 18) * (0.5 + pr);
      ctx.globalAlpha = 1 - pr;
      ctx.strokeStyle = s.big ? "#ffe26b" : "#ffffff";
      ctx.lineWidth = s.big ? 4 : 3;
      for (let i = 0; i < 6; i++) {
        const a = (Math.PI * 2 * i) / 6 + pr * 2;
        ctx.beginPath();
        ctx.moveTo(sx + Math.cos(a) * r * 0.4, s.y + Math.sin(a) * r * 0.4);
        ctx.lineTo(sx + Math.cos(a) * r, s.y + Math.sin(a) * r);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }

    ctx.font = "bold 16px 'Courier New', monospace";
    ctx.textAlign = "center";
    for (const f of this.floaters) {
      const pr = f.t / 0.8;
      ctx.globalAlpha = 1 - pr;
      ctx.fillStyle = f.color;
      ctx.fillText(f.txt, f.x - this.camX, f.y - pr * 34);
    }
    ctx.globalAlpha = 1;
    ctx.textAlign = "left";

    if (this.player.state === "special" && this.player.attack?.weaponFx) {
      this.drawWeaponFx(this.player.attack.weaponFx, this.player);
    }

    // undo the cinematic zoom for screen-space overlays
    if (zoom > 1) {
      const px = this.player.x - this.camX;
      const py = this.player.feetY() - 60;
      ctx.translate(px, py);
      ctx.scale(1 / zoom, 1 / zoom);
      ctx.translate(-px, -py);
    }

    if (this.flashT > 0) {
      ctx.globalAlpha = Math.min(1, this.flashT * 2.2);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(-20, -20, VIEW_W + 40, VIEW_H + 40);
      ctx.globalAlpha = 1;
    }

    if (this.morphT >= 0) this.drawMorphOverlay();
    else this.drawHud();
    ctx.restore();
  }

  /** zoom factor of the cinematic camera during the morph (eases in and out) */
  morphZoom(): number {
    const el = this.morphElapsed();
    if (el < 0) return 1;
    const inK = Math.min(1, el / 0.5);
    const outK = Math.min(1, Math.max(0, (MORPH_DUR - el) / 0.45));
    const k = Math.min(inK, outK);
    const ease = k * k * (3 - 2 * k);
    return 1 + 0.38 * ease;
  }

  /** letterbox bars + captions of the morph cutscene */
  drawMorphOverlay() {
    const ctx = this.ctx;
    const el = this.morphElapsed();
    const inK = Math.min(1, el / 0.3);
    const outK = Math.min(1, Math.max(0, (MORPH_DUR - el) / 0.4));
    const bar = 44 * Math.min(inK, outK);
    ctx.fillStyle = "#000";
    ctx.fillRect(-20, -20, VIEW_W + 40, bar + 20);
    ctx.fillRect(-20, VIEW_H - bar, VIEW_W + 40, bar + 20);

    ctx.textAlign = "center";
    if (el < MORPH_STRIKE) {
      // "IT'S MORPHIN TIME!" — slams in, then holds with a subtle pulse
      const k = Math.min(1, el / 0.25);
      const scale = 1.6 - 0.6 * (k * k * (3 - 2 * k));
      const pulse = 1 + Math.sin(el * 14) * 0.02;
      ctx.save();
      ctx.translate(VIEW_W / 2, 84);
      ctx.scale(scale * pulse, scale * pulse);
      ctx.globalAlpha = k;
      ctx.font = "bold 40px 'Courier New', monospace";
      ctx.lineWidth = 6;
      ctx.strokeStyle = "#000";
      ctx.strokeText("IT'S MORPHIN TIME!", 0, 0);
      ctx.fillStyle = "#ffe26b";
      ctx.fillText("IT'S MORPHIN TIME!", 0, 0);
      ctx.restore();
    } else {
      // dino call in the ranger color + name below
      const k = Math.min(1, (el - MORPH_STRIKE) / 0.22);
      const scale = 1.8 - 0.8 * (k * k * (3 - 2 * k));
      const glow = RANGER_GLOW[this.charKey];
      ctx.save();
      ctx.translate(VIEW_W / 2, 84);
      ctx.scale(scale, scale);
      ctx.globalAlpha = k;
      ctx.font = "bold 44px 'Courier New', monospace";
      ctx.lineWidth = 7;
      ctx.strokeStyle = "#000";
      ctx.strokeText(this.morphCall(), 0, 0);
      ctx.fillStyle = glow === "#ffffff" ? "#f4f4ff" : glow;
      ctx.fillText(this.morphCall(), 0, 0);
      ctx.restore();
      if (el > MORPH_STRIKE + 0.35) {
        ctx.globalAlpha = Math.min(1, (el - MORPH_STRIKE - 0.35) / 0.25);
        ctx.font = "bold 16px 'Courier New', monospace";
        ctx.fillStyle = "#ffffff";
        ctx.fillText(this.rangerName(), VIEW_W / 2, VIEW_H - bar - 14);
        ctx.globalAlpha = 1;
      }
    }
    ctx.textAlign = "left";
  }

  drawMorphFx() {
    const ctx = this.ctx;
    const p = this.player;
    const sx = p.x - this.camX;
    const fy = p.feetY();
    const glow = RANGER_GLOW[this.charKey];
    const el = this.morphElapsed();
    const charging = el >= MORPH_ARM_UP && el < MORPH_STRIKE;
    const done = el >= MORPH_STRIKE;

    // aura: grows while charging, blooms in the ranger color after the strike
    const chargeK = charging ? (el - MORPH_ARM_UP) / (MORPH_STRIKE - MORPH_ARM_UP) : done ? 1 : 0;
    const auraR = 26 + chargeK * 44 + (done ? Math.sin(el * 9) * 6 : 0);
    const rg = ctx.createRadialGradient(sx, fy - 60, 4, sx, fy - 60, auraR + 50);
    rg.addColorStop(0, glow + (done ? "cc" : "88"));
    rg.addColorStop(1, glow + "00");
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.arc(sx, fy - 60, auraR + 50, 0, Math.PI * 2);
    ctx.fill();

    // energy motes orbiting up into the raised morpher
    if (charging || done) {
      for (let i = 0; i < 10; i++) {
        const a = el * 5 + i * 0.63;
        const r = 30 + ((el * 60 + i * 13) % 40);
        const mx = sx + Math.cos(a) * r;
        const my = fy - 40 - ((el * 90 + i * 17) % 110);
        ctx.fillStyle = i % 2 ? "#ffffff" : glow;
        ctx.fillRect(mx - 1.5, my - 1.5, 3, 3);
      }
    }

    // lightning: sparse while charging, a full strike right at the transformation
    const strikeWindow = done && el < MORPH_STRIKE + 0.35;
    if (charging || strikeWindow) {
      const bolts = strikeWindow ? 6 : 2 + Math.floor(chargeK * 3);
      ctx.lineWidth = strikeWindow ? 5 : 3;
      for (let b = 0; b < bolts; b++) {
        if (!strikeWindow && Math.random() < 0.45) continue; // flicker
        ctx.strokeStyle = Math.random() < 0.5 ? "#ffffff" : "#ffe26b";
        ctx.beginPath();
        let x = sx + (Math.random() - 0.5) * (strikeWindow ? 60 : 180);
        let y = -60;
        ctx.moveTo(x, y);
        const tx = sx + (Math.random() - 0.5) * 16;
        const ty = fy - 124 - Math.random() * 16;
        const segs = 8;
        for (let s = 1; s <= segs; s++) {
          const k = s / segs;
          x = x + (tx - x) * k + (Math.random() - 0.5) * 30;
          y = -60 + (ty + 60) * k;
          ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      ctx.globalAlpha = strikeWindow ? 0.9 : 0.5;
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(sx, fy - 130, (strikeWindow ? 18 : 9) + Math.random() * 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }

    // shockwave rings after the strike
    if (done) {
      const k = Math.min(1, (el - MORPH_STRIKE) / 0.6);
      ctx.strokeStyle = glow;
      ctx.lineWidth = 3;
      for (let r = 0; r < 2; r++) {
        const rad = (40 + r * 30) + k * 160;
        ctx.globalAlpha = (1 - k) * (r === 0 ? 0.9 : 0.5);
        ctx.beginPath();
        ctx.ellipse(sx, fy, rad, rad * 0.32, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
  }

  drawOoze(o: StageObj) {
    const ctx = this.ctx;
    const sx = o.x - this.camX;
    const sy = this.objY(o);
    if (sx < -150 || sx > VIEW_W + 150) return;
    const rz = o.zr * ZPX;
    ctx.globalAlpha = 0.85;
    ctx.fillStyle = "#3d1466";
    ctx.beginPath();
    ctx.ellipse(sx, sy, o.w, rz, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#6a2ea3";
    ctx.beginPath();
    ctx.ellipse(sx, sy - 2, o.w - 6, rz - 4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#b27ae6";
    ctx.beginPath();
    ctx.ellipse(sx - o.w * 0.35, sy - rz * 0.35, o.w * 0.25, rz * 0.2, 0, 0, Math.PI * 2);
    ctx.fill();
    // bubbles
    for (let i = 0; i < 4; i++) {
      const ph = (this.time * 1.3 + i * 1.7) % 2;
      const bx = sx + Math.sin(i * 2.3 + o.x) * o.w * 0.6;
      const by = sy + Math.cos(i * 1.9 + o.x) * rz * 0.5;
      ctx.globalAlpha = Math.max(0, 0.8 - ph * 0.4);
      ctx.strokeStyle = "#d9b8ff";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(bx, by, 2 + ph * 4, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  drawObject(o: StageObj) {
    const ctx = this.ctx;
    const sx = Math.round(o.x - this.camX);
    const sy = Math.round(this.objY(o));
    if (sx < -150 || sx > VIEW_W + 150) return;
    // shadow
    ctx.fillStyle = "rgba(0,0,0,0.35)";
    ctx.beginPath();
    ctx.ellipse(sx, sy + 3, o.w + 4, 7, 0, 0, Math.PI * 2);
    ctx.fill();

    if (o.kind === "spikes" || o.kind === "retract") {
      const W = o.w * 2;
      const x0 = sx - o.w;
      ctx.fillStyle = "#3a3d44";
      ctx.fillRect(x0, sy - 8, W, 10);
      ctx.fillStyle = "#5b606a";
      ctx.fillRect(x0, sy - 8, W, 3);
      const n = Math.floor(W / 12);
      let hgt = 22;
      if (o.kind === "retract") hgt = o.up ? 22 : o.warn ? 5 + Math.sin(this.time * 40) * 2 : 0;
      if (o.kind === "retract" && !o.up) {
        ctx.fillStyle = "#1b1d22";
        for (let i = 0; i < n; i++) ctx.fillRect(x0 + i * 12 + 3, sy - 7, 6, 2);
        if (o.warn) {
          ctx.fillStyle = Math.floor(this.time * 10) % 2 ? "#ffde4a" : "#ff8a3a";
          ctx.font = "bold 14px 'Courier New', monospace";
          ctx.textAlign = "center";
          ctx.fillText("!", sx, sy - 14);
          ctx.textAlign = "left";
        }
      }
      if (hgt > 0) {
        for (let i = 0; i < n; i++) {
          const bx = x0 + i * 12 + 6;
          ctx.fillStyle = "#c9ced6";
          ctx.beginPath();
          ctx.moveTo(bx - 5, sy - 7);
          ctx.lineTo(bx, sy - 7 - hgt);
          ctx.lineTo(bx + 5, sy - 7);
          ctx.fill();
          ctx.fillStyle = "#6c737d";
          ctx.beginPath();
          ctx.moveTo(bx, sy - 7 - hgt);
          ctx.lineTo(bx + 5, sy - 7);
          ctx.lineTo(bx + 1, sy - 7);
          ctx.fill();
        }
      }
      return;
    }
    if (o.kind === "crate") {
      const s = 44, wob = o.wobble > 0 ? Math.sin(this.time * 60) * 3 : 0;
      const x0 = sx - s / 2 + wob, y0 = sy - s;
      ctx.fillStyle = "#a86a2c"; ctx.fillRect(x0, y0, s, s);
      ctx.fillStyle = "#6b3f14";
      ctx.fillRect(x0, y0, s, 4); ctx.fillRect(x0, y0 + s - 4, s, 4);
      ctx.fillRect(x0, y0, 4, s); ctx.fillRect(x0 + s - 4, y0, 4, s);
      ctx.strokeStyle = "#6b3f14"; ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(x0 + 5, y0 + 5); ctx.lineTo(x0 + s - 5, y0 + s - 5);
      ctx.moveTo(x0 + s - 5, y0 + 5); ctx.lineTo(x0 + 5, y0 + s - 5);
      ctx.stroke();
      ctx.fillStyle = "#d9a15c"; ctx.fillRect(x0 + 6, y0 + 6, s - 12, 2);
      if (o.hp <= 2) {
        ctx.strokeStyle = "#2a1608"; ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x0 + 10, y0 + 8); ctx.lineTo(x0 + 18, y0 + 20); ctx.lineTo(x0 + 12, y0 + 30);
        ctx.stroke();
      }
      if (o.hp <= 1) {
        ctx.beginPath();
        ctx.moveTo(x0 + s - 8, y0 + 12); ctx.lineTo(x0 + s - 20, y0 + 22); ctx.lineTo(x0 + s - 10, y0 + 36);
        ctx.stroke();
      }
      return;
    }
    if (o.kind === "barrel" || o.kind === "firebarrel") {
      const rolling = o.kind === "barrel" && Math.abs(o.vx) >= 40;
      const body = o.kind === "firebarrel" ? "#6b3a1e" : "#4c6b8a";
      const band = o.kind === "firebarrel" ? "#3d2010" : "#2b3d50";
      const hi = o.kind === "firebarrel" ? "#9a5a34" : "#7f9fbd";
      if (rolling) {
        const w = 52, h = 40, x0 = sx - w / 2, y0 = sy - h;
        ctx.fillStyle = body; ctx.fillRect(x0, y0, w, h);
        ctx.fillStyle = band; ctx.fillRect(x0 + 8, y0, 5, h); ctx.fillRect(x0 + w - 13, y0, 5, h);
        const off = ((o.rot % (Math.PI * 2)) / (Math.PI * 2)) * h;
        ctx.fillStyle = hi; ctx.fillRect(x0, y0 + ((off + h) % h), w, 4);
        ctx.fillStyle = band; ctx.fillRect(x0, y0, w, 3); ctx.fillRect(x0, y0 + h - 3, w, 3);
      } else {
        const w = 40, h = 52, wob = o.wobble > 0 ? Math.sin(this.time * 50) * 2 : 0;
        const x0 = sx - w / 2 + wob, y0 = sy - h;
        ctx.fillStyle = body; ctx.fillRect(x0, y0, w, h);
        ctx.fillStyle = hi; ctx.fillRect(x0 + 6, y0 + 4, 5, h - 8);
        ctx.fillStyle = band; ctx.fillRect(x0, y0 + 8, w, 5); ctx.fillRect(x0, y0 + h - 14, w, 5);
        ctx.beginPath(); ctx.ellipse(sx + wob, y0, w / 2, 5, 0, 0, Math.PI * 2); ctx.fill();
        if (o.kind === "firebarrel") {
          for (let i = 0; i < 5; i++) {
            const fx = sx + wob - 14 + i * 7 + Math.sin(this.time * 18 + i * 2) * 2;
            const fh = 22 + Math.sin(this.time * 14 + i * 3.1 + o.x) * 9;
            const grad = ctx.createLinearGradient(0, y0 - fh, 0, y0);
            grad.addColorStop(0, "#ffe26b"); grad.addColorStop(0.5, "#ff8c2e"); grad.addColorStop(1, "#d43518");
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.moveTo(fx - 5, y0 + 2); ctx.quadraticCurveTo(fx - 4, y0 - fh * 0.5, fx, y0 - fh);
            ctx.quadraticCurveTo(fx + 4, y0 - fh * 0.5, fx + 5, y0 + 2);
            ctx.fill();
          }
        }
      }
    }
  }

  drawPickup(it: Pickup) {
    const ctx = this.ctx;
    const sx = it.x - this.camX;
    const groundY = GROUND_TOP + it.z * ZPX;
    const sy = groundY - 14 - Math.abs(Math.sin(it.t * 3)) * 10;
    if (sx < -50 || sx > VIEW_W + 50) return;
    if (groundY < 60 || groundY > VIEW_H + 20) return;
    if (it.t > 11 && Math.floor(it.t * 8) % 2 === 0) return;
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.beginPath(); ctx.ellipse(sx, GROUND_TOP + it.z * ZPX + 2, 10, 4, 0, 0, Math.PI * 2); ctx.fill();
    const rg = ctx.createRadialGradient(sx, sy, 2, sx, sy, 26);
    rg.addColorStop(0, "rgba(255,226,107,0.5)"); rg.addColorStop(1, "rgba(255,226,107,0)");
    ctx.fillStyle = rg; ctx.fillRect(sx - 26, sy - 26, 52, 52);
    ctx.fillStyle = "#ffe26b"; ctx.strokeStyle = "#b07a00"; ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(sx + 4, sy - 16); ctx.lineTo(sx - 8, sy + 2);
    ctx.lineTo(sx - 1, sy + 2); ctx.lineTo(sx - 4, sy + 16);
    ctx.lineTo(sx + 8, sy - 3); ctx.lineTo(sx + 1, sy - 3);
    ctx.closePath(); ctx.fill(); ctx.stroke();
  }

  hazardScreenPos(h: Hazard): [number, number] {
    return [h.x - this.camX, GROUND_TOP + h.z * ZPX];
  }

  drawHazardGround(h: Hazard) {
    const ctx = this.ctx;
    const [sx, sy] = this.hazardScreenPos(h);
    if (sx < -80 || sx > VIEW_W + 80) return;
    const warning = h.t <= h.warnT, active = h.t > h.warnT && h.t < h.warnT + h.activeT;
    if (warning) {
      const blink = Math.floor(h.t * 8) % 2 === 0;
      ctx.globalAlpha = blink ? 0.85 : 0.4;
      ctx.strokeStyle = "#ffde4a"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.ellipse(sx, sy, 42, 13, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = "#ffde4a"; ctx.font = "bold 18px 'Courier New', monospace";
      ctx.textAlign = "center"; ctx.fillText("!", sx, sy - 6); ctx.textAlign = "left";
      ctx.globalAlpha = 1; return;
    }
    if (!active) return;
    const at = h.t - h.warnT;
    if (h.type === "fire") {
      ctx.fillStyle = "rgba(20,10,5,0.55)"; ctx.beginPath(); ctx.ellipse(sx, sy, 48, 13, 0, 0, Math.PI * 2); ctx.fill();
      for (let i = 0; i < 7; i++) {
        const fx = sx - 36 + i * 12 + Math.sin(at * 20 + i * 2) * 3;
        const fh = 26 + Math.sin(at * 16 + i * 3.1) * 10;
        const grad = ctx.createLinearGradient(0, sy - fh, 0, sy);
        grad.addColorStop(0, "#ffe26b"); grad.addColorStop(0.5, "#ff8c2e"); grad.addColorStop(1, "#d43518");
        ctx.fillStyle = grad; ctx.beginPath();
        ctx.moveTo(fx - 6, sy); ctx.quadraticCurveTo(fx - 4, sy - fh * 0.5, fx, sy - fh);
        ctx.quadraticCurveTo(fx + 4, sy - fh * 0.5, fx + 6, sy); ctx.fill();
      }
    } else if (h.type === "spark") {
      ctx.strokeStyle = Math.floor(at * 24) % 2 ? "#9adfff" : "#ffffff"; ctx.lineWidth = 2.5;
      for (let b = 0; b < 3; b++) {
        ctx.beginPath(); let px = sx - 44, py = sy - 4 - b * 3; ctx.moveTo(px, py);
        for (let seg = 0; seg < 6; seg++) { px += 15; py = sy - 4 - Math.random() * 26; ctx.lineTo(px, py); }
        ctx.stroke();
      }
    }
  }

  drawHazardAir(h: Hazard) {
    if (h.type !== "girder") return;
    const ctx = this.ctx;
    const [sx, sy] = this.hazardScreenPos(h);
    if (sx < -80 || sx > VIEW_W + 80) return;
    const active = h.t > h.warnT && h.t < h.warnT + h.activeT + 0.35;
    if (!active) return;
    const at = h.t - h.warnT, fallDur = 0.22, prog = Math.min(1, at / fallDur);
    // cap beam so it never draws past the bottom of the viewport
    const groundY = Math.min(sy - 4, VIEW_H);
    const skyY = -160;
    const beamH = groundY - skyY;
    const y = skyY + prog * (groundY - skyY);
    const topY = Math.min(y, groundY - 6);
    const drawY = Math.max(0, topY);
    const drawH = Math.min(beamH, groundY - drawY);
    if (drawH <= 0) return;
    ctx.fillStyle = "#8d939e"; ctx.fillRect(sx - 13, drawY, 26, drawH);
    ctx.fillStyle = "#6b7076"; ctx.fillRect(sx - 13, drawY, 5, drawH);
    ctx.fillStyle = "#b9bec7"; ctx.fillRect(sx + 7, drawY, 4, drawH);
  }

  drawFighter(f: Fighter) {
    const ctx = this.ctx;
    if (f.flicker > 0 && Math.floor(f.flicker * 20) % 2 === 0) return;
    if (f.invuln > 0 && f.isPlayer && this.morphT < 0 && Math.floor(f.invuln * 24) % 3 === 0) return;
    const an = f.currentAnim();
    const fr = an.frames[f.frameIndex()] || an.frames[0];
    if (!fr) return;
    const img = getImage(f.sheet);
    const sx = f.x - this.camX;
    if (sx < -120 || sx > VIEW_W + 120) return;
    const fy = f.feetY();
    const sh = Math.max(0.4, 1 - f.h / 220);
    ctx.fillStyle = `rgba(0,0,0,${0.35 * sh})`;
    ctx.beginPath(); ctx.ellipse(sx, fy + 4, 26 * sh, 8 * sh, 0, 0, Math.PI * 2); ctx.fill();
    const w = fr.w * SCALE, h = fr.h * SCALE;
    ctx.save();
    ctx.translate(Math.round(sx), Math.round(fy - f.h));
    if (f.facing < 0) ctx.scale(-1, 1);
    if (f.hitFlash > 0) {
      ctx.filter = "brightness(2.6) saturate(0.4)";
      ctx.drawImage(img, fr.x, fr.y, fr.w, fr.h, Math.round(-w / 2), -h, w, h);
      ctx.filter = "none";
    } else {
      ctx.drawImage(img, fr.x, fr.y, fr.w, fr.h, Math.round(-w / 2), -h, w, h);
    }
    ctx.restore();
    if (!f.isPlayer && f.hp < f.maxHp && f.hp > 0) {
      const bw = 46;
      ctx.fillStyle = "rgba(0,0,0,0.5)"; ctx.fillRect(sx - bw / 2, fy - f.h - h - 14, bw, 5);
      ctx.fillStyle = f.kind === "oozeman" ? "#b06be0" : f.kind === "skelerena" ? "#e0c46b" : "#c8cad0";
      ctx.fillRect(sx - bw / 2, fy - f.h - h - 14, (bw * f.hp) / f.maxHp, 5);
    }
  }

  drawWeaponFx(fx: WeaponFx, p: Fighter) {
    const ctx = this.ctx;
    const sx = p.x - this.camX;
    const fy = p.feetY();
    const dir = p.facing;
    const t = p.t;
    switch (fx) {
      case "sword_slash": {
        // big diagonal arc traveling right
        const prog = Math.min(1, t * 1.6);
        ctx.strokeStyle = "#ffe26b";
        ctx.lineWidth = 4;
        const r = 110 * prog;
        const ang = -Math.PI * 0.7 + prog * Math.PI * 0.4;
        const cx = sx + dir * 70, cy = fy - 60;
        ctx.beginPath();
        ctx.arc(cx, cy, r, ang - 0.5, ang + 0.5);
        ctx.stroke();
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(cx, cy, r * 0.6, ang - 0.4, ang + 0.4);
        ctx.stroke();
        break;
      }
      case "axe_smash": {
        const prog = Math.min(1, t * 1.5);
        ctx.fillStyle = "rgba(255,200,80,0.7)";
        ctx.beginPath();
        ctx.ellipse(sx + dir * 50, fy - 30, 70 * prog, 90 * prog, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#ffec7a";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(sx, fy - 60);
        ctx.lineTo(sx + dir * 90, fy - 10);
        ctx.stroke();
        break;
      }
      case "lance_thrust": {
        const prog = Math.min(1, t * 2.0);
        const reach = 200 * prog;
        const cy = fy - 50;
        ctx.fillStyle = "rgba(80,160,255,0.85)";
        ctx.beginPath();
        ctx.moveTo(sx + dir * 6, cy - 8);
        ctx.lineTo(sx + dir * (reach + 8), cy);
        ctx.lineTo(sx + dir * 6, cy + 8);
        ctx.closePath();
        ctx.fill();
        // tip flare
        ctx.fillStyle = "#fff";
        ctx.beginPath();
        ctx.arc(sx + dir * reach, cy, 6, 0, Math.PI * 2);
        ctx.fill();
        // sparkles along
        for (let i = 1; i < 4; i++) {
          const px = sx + dir * (reach * (i / 4));
          const py = cy + (Math.random() - 0.5) * 6;
          ctx.fillStyle = "#9adfff";
          ctx.fillRect(px - 1, py - 1, 2, 2);
        }
        break;
      }
      case "dagger_slash": {
        // twin crossing dagger arcs with a golden sparkle trail
        const prog = Math.min(1, t * 1.8);
        const cx = sx + dir * 48, cy = fy - 58;
        ctx.lineWidth = 3;
        for (let k = 0; k < 2; k++) {
          const flip = k === 0 ? 1 : -1;
          const r = 52 + prog * 26;
          const a0 = (flip > 0 ? -1.1 : 0.2) + prog * 0.9 * flip;
          ctx.strokeStyle = k === 0 ? "#ffe26b" : "#ffffff";
          ctx.beginPath();
          ctx.arc(cx, cy + flip * 8, r, a0, a0 + 0.9, false);
          ctx.stroke();
        }
        for (let i = 0; i < 6; i++) {
          const ang = -0.9 + i * 0.35 + prog;
          const rr = 60 + Math.random() * 30;
          ctx.fillStyle = i % 2 ? "#fff3a6" : "#ffffff";
          ctx.fillRect(cx + Math.cos(ang) * rr * dir - 1, cy + Math.sin(ang) * rr - 1, 3, 3);
        }
        break;
      }
      case "arrow_rain": {
        // 3 arrows arcing
        const col2 = "#ffe26b";
        for (let i = 0; i < 3; i++) {
          const k = ((t * 2) - i * 0.3 + 1) % 1.3;
          const ay = fy - 130 + k * 130;
          const ax = sx + dir * (40 + i * 50);
          ctx.fillStyle = col2;
          ctx.beginPath();
          ctx.moveTo(ax - 6, ay);
          ctx.lineTo(ax + 6, ay);
          ctx.lineTo(ax, ay + 8);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = "#fff";
          ctx.fillRect(ax - 0.5, ay - 12, 1, 14);
        }
        break;
      }
      case "sabersword": {
        // twin crescent waves
        const cx = sx + dir * 40, cy = fy - 60;
        const prog = Math.min(1, t * 1.5);
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 5;
        for (let w = 0; w < 2; w++) {
          ctx.beginPath();
          for (let s = 0; s <= 30; s++) {
            const a = -Math.PI * 0.5 + s * 0.1;
            const r = (110 + w * 24) * prog;
            const xx = cx + Math.cos(a) * r * dir;
            const yy = cy + Math.sin(a) * r + (w === 0 ? -10 : 10);
            if (s === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy);
          }
          ctx.stroke();
        }
        break;
      }
    }
  }

  drawHud() {
    const ctx = this.ctx;
    const st = this.stage(), p = this.player;
    ctx.fillStyle = "rgba(0,0,0,0.55)"; ctx.fillRect(20, 18, 320, 54);
    ctx.strokeStyle = "#ffffff"; ctx.lineWidth = 2; ctx.strokeRect(20, 18, 320, 54);
    ctx.font = "bold 13px 'Courier New', monospace"; ctx.fillStyle = "#ffffff"; ctx.fillText("ENERGIA", 32, 36);
    ctx.fillStyle = "#3a3f4a"; ctx.fillRect(32, 44, 296, 16);
    const ratio = Math.max(0, p.hp) / p.maxHp;
    const hpg = ctx.createLinearGradient(32, 0, 328, 0);
    hpg.addColorStop(0, ratio > 0.35 ? "#37d05c" : "#e0442e");
    hpg.addColorStop(1, ratio > 0.35 ? "#9cf22e" : "#ff9a2e");
    ctx.fillStyle = hpg; ctx.fillRect(32, 44, 296 * ratio, 16);
    ctx.fillStyle = "rgba(0,0,0,0.55)"; ctx.fillRect(VIEW_W - 290, 18, 270, 54);
    ctx.strokeRect(VIEW_W - 290, 18, 270, 54);
    ctx.fillStyle = "#ffe26b"; ctx.font = "bold 15px 'Courier New', monospace";
    ctx.fillText(`PONTOS ${String(this.score).padStart(6, "0")}`, VIEW_W - 276, 40);
    ctx.fillStyle = "#ffffff";
    ctx.fillText(
      `FASE ${this.phase + 1}/${STAGES.length}  ONDA ${Math.min(this.wave + 1, st.waves.length)}/${st.waves.length}  VILÕES ${this.enemies.filter((e) => e.removeT === -1).length + this.toSpawn}`,
      VIEW_W - 276, 62);
    ctx.fillStyle = "rgba(0,0,0,0.55)"; ctx.fillRect(20, 80, 180, 26); ctx.strokeRect(20, 80, 180, 26);
    ctx.font = "bold 11px 'Courier New', monospace";
    if (!this.morphed) {
      if (this.morphMeter >= 1) {
        ctx.fillStyle = Math.floor(performance.now() / 250) % 2 ? "#ffe26b" : "#ffffff";
        ctx.fillText("MORFAR! [M]", 30, 97);
      } else {
        ctx.fillStyle = "#8a6ad4"; ctx.fillRect(22, 82, 176 * this.morphMeter, 22);
        ctx.fillStyle = "#dfe6ee"; ctx.fillText("PODER DE MORFAGEM", 30, 97);
      }
    } else if (this.specialCd <= 0) {
      ctx.fillStyle = "#ffe26b"; ctx.fillText("ARMA PRONTA! [C]", 30, 97);
    } else {
      ctx.fillStyle = "#2b7fd4"; ctx.fillRect(22, 82, 176 * (1 - this.specialCd / 5), 22);
      ctx.fillStyle = "#dfe6ee"; ctx.fillText("RECARREGANDO...", 30, 97);
    }
    // combo counter (below the score box, right side)
    if (this.comboStep > 0) {
      const labels = ["SOCO", "SOCO 2", "SOCO 3!"];
      const colors = ["#ffe26b", "#ffd24a", "#ff9a2e"];
      ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.fillRect(VIEW_W - 200, 80, 180, 26);
      ctx.font = "bold 13px 'Courier New', monospace";
      ctx.fillStyle = colors[this.comboStep - 1];
      ctx.fillText(`COMBO ${this.comboStep} ${labels[this.comboStep - 1]}`, VIEW_W - 192, 97);
    }
    ctx.fillStyle = "rgba(0,0,0,0.45)"; ctx.fillRect(20, VIEW_H - 34, 250, 22);
    ctx.fillStyle = "#9fb6d8"; ctx.font = "bold 11px 'Courier New', monospace";
    ctx.fillText(`${this.phase + 1}. ${st.name}`, 28, VIEW_H - 19);
    if (this.bannerT > 0 && !this.over) {
      const a = Math.min(1, this.bannerT);
      ctx.globalAlpha = a; ctx.fillStyle = "rgba(0,0,0,0.62)"; ctx.fillRect(0, 158, VIEW_W, 96);
      ctx.fillStyle = "#ffe26b"; ctx.font = "bold 42px 'Courier New', monospace";
      ctx.textAlign = "center"; ctx.fillText(this.bannerBig, VIEW_W / 2, 206);
      ctx.fillStyle = "#ffffff"; ctx.font = "bold 16px 'Courier New', monospace";
      ctx.fillText(this.bannerSmall, VIEW_W / 2, 236); ctx.textAlign = "left"; ctx.globalAlpha = 1;
    }
    if (this.endT > 0) {
      ctx.fillStyle = "rgba(0,0,0,0.5)"; ctx.fillRect(0, 162, VIEW_W, 84);
      ctx.fillStyle = "#7bf26b"; ctx.font = "bold 40px 'Courier New', monospace";
      ctx.textAlign = "center"; ctx.fillText("ANGEL GROVE ESTÁ SALVA!", VIEW_W / 2, 216);
      ctx.textAlign = "left";
    }
  }
}
